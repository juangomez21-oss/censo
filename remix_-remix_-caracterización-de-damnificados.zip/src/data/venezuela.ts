/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DivisionPolitica } from '../types';

export const DIVISION_VENEZUELA_DEFAULT: DivisionPolitica = {
  estados: {
    "Distrito Capital": {
      municipios: {
        "Municipio Bolivariano Libertador": [
          "23 de Enero",
          "Altagracia",
          "Antímano",
          "Caricuao",
          "Catedral",
          "Coche",
          "El Junquito",
          "El Paraíso",
          "El Recreo",
          "El Valle",
          "La Candelaria",
          "La Pastora",
          "La Vega",
          "Macarao",
          "San Agustín",
          "San Bernardino",
          "San José",
          "San Juan",
          "San Pedro",
          "Santa Rosalía",
          "Santa Teresa",
          "Sucre (Catia)"
        ]
      }
    },
    "Miranda": {
      municipios: {
        "Municipio Chacao": ["Chacao"],
        "Municipio Sucre": ["Petare", "Leoncio Martínez", "Caucagüita", "Filas de Mariche", "La Dolorita"],
        "Municipio Baruta": ["Nuestra Señora del Rosario de Baruta", "El Cafetal", "Las Minas de Baruta"],
        "Municipio El Hatillo": ["El Hatillo"],
        "Municipio Plaza": ["Guarenas"],
        "Municipio Zamora": ["Guatire", "Araira"],
        "Municipio Cristóbal Rojas": ["Charallave", "Las Brisas"],
        "Municipio Lander": ["Ocumare del Tuy", "Santa Bárbara", "La Democracia"]
      }
    },
    "Zulia": {
      municipios: {
        "Municipio Maracaibo": [
          "Juana de Ávila",
          "Coquivacoa",
          "Chiquinquirá",
          "Cacique Mara",
          "Olegario Villalobos",
          "Francisco Eugenio Bustamante",
          "Bolívar",
          "Caracciolo Parra Pérez",
          "Cecilio Acosta",
          "Cristo de Aranza",
          "Idelfonso Vásquez",
          "Manuel Dagnino",
          "San Isidro",
          "Santa Lucía",
          "Venancio Pulgar"
        ],
        "Municipio San Francisco": [
          "San Francisco",
          "El Bajo",
          "Domitila Flores",
          "Francisco Ochoa",
          "Los Cortijos",
          "Marcial Hernández"
        ],
        "Municipio Cabimas": ["Ambrosio", "Carmen Herrera", "Germán Ríos Linares", "La Rosa", "Jorge Hernández", "Punta Gorda"]
      }
    },
    "Carabobo": {
      municipios: {
        "Municipio Valencia": ["El Socorro", "San Blas", "Santa Rosa", "Miguel Peña", "Rafael Urdaneta", "San José", "Catedral", "Candelaria", "Negro Primero"],
        "Municipio Naguanagua": ["Naguanagua"],
        "Municipio San Diego": ["San Diego"],
        "Municipio Puerto Cabello": ["Bartolomé Salom", "Democracia", "Fraternidad", "Goaigoaza", "Juan José Flores", "Unión"]
      }
    },
    "Aragua": {
      municipios: {
        "Municipio Girardot": ["Las Delicias", "Choroní", "Madre María de San José", "Joaquín Crespo", "Pedro José Ovalle", "José Casanova Godoy", "Andrés Eloy Blanco"],
        "Municipio Santiago Mariño": ["Turmero", "Arévalo Aponte", "Chuao", "Samán de Güere", "Alfredo Pacheco Miranda"]
      }
    },
    "Lara": {
      municipios: {
        "Municipio Iribarren": ["Catedral", "Concepción", "Santa Rosa", "Unión", "El Cují", "Tamaca", "Juan de Villegas", "Aguedo Felipe Alvarado", "Buena Vista", "Juárez"],
        "Municipio Palavecino": ["Cabudare", "José Gregorio Bastidas", "Agua Viva"]
      }
    },
    "La Guaira": {
      municipios: {
        "Municipio Vargas": ["Caraballeda", "Carayaca", "Catia La Mar", "La Guaira", "Macuto", "Maiquetía", "Naiguatá", "El Junko", "Carlos Soublette", "Raúl Leoni", "Urimare"]
      }
    }
  }
};

const STORAGE_KEY = 'venezuela_division_territorial';

export function getDivisionPolitica(): DivisionPolitica {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error("Error parsing division politica, restoring default", e);
    }
  }
  return DIVISION_VENEZUELA_DEFAULT;
}

export function saveDivisionPolitica(division: DivisionPolitica) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(division));
}

export function agregarEstado(estado: string): DivisionPolitica {
  const current = getDivisionPolitica();
  if (estado && !current.estados[estado]) {
    current.estados[estado] = { municipios: {} };
    saveDivisionPolitica(current);
  }
  return current;
}

export function agregarMunicipio(estado: string, municipio: string): DivisionPolitica {
  const current = getDivisionPolitica();
  if (estado && municipio && current.estados[estado]) {
    if (!current.estados[estado].municipios[municipio]) {
      current.estados[estado].municipios[municipio] = [];
      saveDivisionPolitica(current);
    }
  }
  return current;
}

export function agregarParroquia(estado: string, municipio: string, parroquia: string): DivisionPolitica {
  const current = getDivisionPolitica();
  if (estado && municipio && parroquia && current.estados[estado] && current.estados[estado].municipios[municipio]) {
    if (!current.estados[estado].municipios[municipio].includes(parroquia)) {
      current.estados[estado].municipios[municipio].push(parroquia);
      saveDivisionPolitica(current);
    }
  }
  return current;
}
