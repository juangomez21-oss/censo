/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Camera, Info, Save, X, PlusCircle } from 'lucide-react';
import { FichaSocial, Familiar, DivisionPolitica } from '../types';
import { getDivisionPolitica, agregarEstado, agregarMunicipio, agregarParroquia } from '../data/venezuela';
import { calculateAge, formatVenezuelaPhone, compressImage } from '../utils/helpers';

interface FormularioFichaProps {
  editFicha?: FichaSocial | null;
  onSave: (ficha: FichaSocial) => void;
  onCancel: () => void;
}

export default function FormularioFicha({ editFicha, onSave, onCancel }: FormularioFichaProps) {
  // --- STATE FOR GEOGRAPHICAL DATABASE ---
  const [division, setDivision] = useState<DivisionPolitica>(getDivisionPolitica());
  
  // Custom Addition Modal State
  const [modalOpen, setModalOpen] = useState<'estado' | 'municipio' | 'parroquia' | null>(null);
  const [newItemName, setNewItemName] = useState('');

  // --- FORM FIELDS STATE ---
  // Datos Jefe de Familia
  const [cedula, setCedula] = useState('');
  const [nombres, setNombres] = useState('');
  const [apellidos, setApellidos] = useState('');
  const [fechaNacimiento, setFechaNacimiento] = useState('');
  const [edad, setEdad] = useState(0);
  const [telefono, setTelefono] = useState('+058 ');
  const [sexo, setSexo] = useState<'Masculino' | 'Femenino' | 'Otro'>('Masculino');
  const [gradoInstruccion, setGradoInstruccion] = useState('Ninguno');
  const [tallaCamisa, setTallaCamisa] = useState('M');
  const [tallaPantalon, setTallaPantalon] = useState('32');
  const [numeroCalzado, setNumeroCalzado] = useState('40');
  const [profesionOficio, setProfesionOficio] = useState('');
  const [tipoEnfermedad, setTipoEnfermedad] = useState('Ninguna');
  const [tratamientoMedicoActivo, setTratamientoMedicoActivo] = useState<'Sí' | 'No'>('No');
  const [discapacidad, setDiscapacidad] = useState<'Sí' | 'No'>('No');
  const [tipoDiscapacidad, setTipoDiscapacidad] = useState('');
  const [alergico, setAlergico] = useState<'Sí' | 'No'>('No');
  const [medicamentoAlergico, setMedicamentoAlergico] = useState('');

  // Equipo Responsable de Familia
  const [fechaIngreso, setFechaIngreso] = useState(new Date().toISOString().split('T')[0]);
  const [direccionProcedencia, setDireccionProcedencia] = useState('');
  const [estado, setEstado] = useState('');
  const [municipio, setMunicipio] = useState('');
  const [parroquia, setParroquia] = useState('');
  const [responsableFamilia, setResponsableFamilia] = useState('');
  const [telefonoResponsable, setTelefonoResponsable] = useState('+058 ');

  // Datos Grupo Familiar
  const [grupoFamiliar, setGrupoFamiliar] = useState<Familiar[]>([]);
  
  // Temporary State for adding a familiar
  const [famParentezco, setFamParentezco] = useState('Hijo/a');
  const [famNombres, setFamNombres] = useState('');
  const [famEdad, setFamEdad] = useState('');
  const [famSexo, setFamSexo] = useState<'Masculino' | 'Femenino' | 'Otro'>('Masculino');
  const [famCamisa, setFamCamisa] = useState('M');
  const [famPantalon, setFamPantalon] = useState('30');
  const [famCalzado, setFamCalzado] = useState('38');
  const [famEnfermedad, setFamEnfermedad] = useState('Ninguna');
  const [famAlergico, setFamAlergico] = useState<'Sí' | 'No'>('No');

  // Información General
  const [situacionActual, setSituacionActual] = useState('');

  // Memoria Fotográfica
  const [imagenes, setImagenes] = useState<string[]>([]);
  const [imageError, setImageError] = useState<string | null>(null);

  // --- INITIAL LOAD (FOR EDIT MODE) ---
  useEffect(() => {
    if (editFicha) {
      setCedula(editFicha.cedula);
      setNombres(editFicha.nombres);
      setApellidos(editFicha.apellidos);
      setFechaNacimiento(editFicha.fechaNacimiento);
      setEdad(editFicha.edad);
      setTelefono(editFicha.telefono);
      setSexo(editFicha.sexo);
      setGradoInstruccion(editFicha.gradoInstruccion);
      setTallaCamisa(editFicha.tallaCamisa);
      setTallaPantalon(editFicha.tallaPantalon);
      setNumeroCalzado(editFicha.numeroCalzado);
      setProfesionOficio(editFicha.profesionOficio);
      setTipoEnfermedad(editFicha.tipoEnfermedad);
      setTratamientoMedicoActivo(editFicha.tratamientoMedicoActivo);
      setDiscapacidad(editFicha.discapacidad);
      setTipoDiscapacidad(editFicha.tipoDiscapacidad);
      setAlergico(editFicha.alergico);
      setMedicamentoAlergico(editFicha.medicamentoAlergico);

      setFechaIngreso(editFicha.fechaIngreso);
      setDireccionProcedencia(editFicha.direccionProcedencia);
      
      // Handle custom selections safely
      setEstado(editFicha.estado);
      setMunicipio(editFicha.municipio);
      setParroquia(editFicha.parroquia);
      
      setResponsableFamilia(editFicha.responsableFamilia);
      setTelefonoResponsable(editFicha.telefonoResponsable);
      setGrupoFamiliar(editFicha.grupoFamiliar);
      setSituacionActual(editFicha.situacionActual);
      setImagenes(editFicha.imagenes || []);
    } else {
      // Set default first state
      const firstEstado = Object.keys(division.estados)[0] || '';
      setEstado(firstEstado);
      if (firstEstado) {
        const firstMun = Object.keys(division.estados[firstEstado]?.municipios || {})[0] || '';
        setMunicipio(firstMun);
        if (firstMun) {
          setParroquia(division.estados[firstEstado]?.municipios[firstMun]?.[0] || '');
        }
      }
    }
  }, [editFicha, division]);

  // --- EFFECT: REAL-TIME LIVE AGE CALCULATION ---
  useEffect(() => {
    if (fechaNacimiento) {
      const computedAge = calculateAge(fechaNacimiento, fechaIngreso);
      setEdad(computedAge);
    }
  }, [fechaNacimiento, fechaIngreso]);

  // --- UPDATE SELECTS CASCADE ---
  const handleEstadoChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedEst = e.target.value;
    setEstado(selectedEst);
    const muns = Object.keys(division.estados[selectedEst]?.municipios || {});
    const firstMun = muns[0] || '';
    setMunicipio(firstMun);
    if (firstMun) {
      setParroquia(division.estados[selectedEst]?.municipios[firstMun]?.[0] || '');
    } else {
      setParroquia('');
    }
  };

  const handleMunicipioChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedMun = e.target.value;
    setMunicipio(selectedMun);
    const parrs = division.estados[estado]?.municipios[selectedMun] || [];
    setParroquia(parrs[0] || '');
  };

  // --- ADDING CUSTOM ITEMS TO HIERARCHY ---
  const handleOpenAddModal = (type: 'estado' | 'municipio' | 'parroquia') => {
    setModalOpen(type);
    setNewItemName('');
  };

  const handleSaveCustomItem = () => {
    const trimmed = newItemName.trim();
    if (!trimmed) return;

    if (modalOpen === 'estado') {
      const updated = agregarEstado(trimmed);
      setDivision(updated);
      setEstado(trimmed);
      setMunicipio('');
      setParroquia('');
    } else if (modalOpen === 'municipio') {
      if (!estado) return;
      const updated = agregarMunicipio(estado, trimmed);
      setDivision(updated);
      setMunicipio(trimmed);
      setParroquia('');
    } else if (modalOpen === 'parroquia') {
      if (!estado || !municipio) return;
      const updated = agregarParroquia(estado, municipio, trimmed);
      setDivision(updated);
      setParroquia(trimmed);
    }

    setModalOpen(null);
  };

  // --- REQUISITES: LIVE FORMAT TELEPHONES ---
  const handleTelefonoJefeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTelefono(formatVenezuelaPhone(e.target.value));
  };

  const handleTelefonoResponsableChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTelefonoResponsable(formatVenezuelaPhone(e.target.value));
  };

  // --- GROUP FAMILY MANAGEMENT ---
  const handleAddFamiliar = () => {
    if (!famNombres.trim()) {
      alert('Por favor ingrese el nombre y apellido del familiar.');
      return;
    }
    const ageNum = parseInt(famEdad);
    if (isNaN(ageNum) || ageNum < 0) {
      alert('Por favor ingrese una edad válida.');
      return;
    }

    const newFamiliar: Familiar = {
      id: `fam-${Date.now()}`,
      parentezco: famParentezco,
      nombresApellidos: famNombres.trim(),
      edad: ageNum,
      sexo: famSexo,
      tallaCamisa: famCamisa,
      tallaPantalon: famPantalon,
      numeroCalzado: famCalzado,
      tipoEnfermedad: famEnfermedad.trim() || 'Ninguna',
      alergica: famAlergico
    };

    setGrupoFamiliar([...grupoFamiliar, newFamiliar]);
    
    // Clear sub-inputs
    setFamNombres('');
    setFamEdad('');
    setFamEnfermedad('Ninguna');
    setFamAlergico('No');
  };

  const handleRemoveFamiliar = (id: string) => {
    setGrupoFamiliar(grupoFamiliar.filter(f => f.id !== id));
  };

  // --- MEMORIA FOTOGRÁFICA UPLOADS & AUTOMATIC SIZE OPTIMIZER (< 1MB) ---
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    setImageError(null);
    const newImgs: string[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        setImageError('Tipo de archivo no soportado. Por favor use JPG, PNG o WEBP.');
        continue;
      }

      try {
        // Automatically compress and fit the base64 under 1MB as requested!
        const compressedBase64 = await compressImage(file);
        newImgs.push(compressedBase64);
      } catch (err) {
        console.error('Error compressing image:', err);
        setImageError('Ocurrió un problema al optimizar el tamaño de la imagen.');
      }
    }

    setImagenes([...imagenes, ...newImgs]);
  };

  const handleRemoveImage = (index: number) => {
    setImagenes(imagenes.filter((_, i) => i !== index));
  };

  // --- TOTAL SUM CALCULATION: 1 Jefe + members ---
  const totalCantidadPersonas = 1 + grupoFamiliar.length;

  // --- SUBMIT COMPLETED SOCIAL RECORD ---
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();

    if (!cedula.trim()) {
      alert('La cédula del jefe de familia es obligatoria.');
      return;
    }
    if (!nombres.trim() || !apellidos.trim()) {
      alert('Nombres y apellidos del jefe de familia son obligatorios.');
      return;
    }

    const fichaCompleta: FichaSocial = {
      id: editFicha ? editFicha.id : `ficha-${Date.now()}`,
      cedula: cedula.trim(),
      nombres: nombres.trim(),
      apellidos: apellidos.trim(),
      fechaNacimiento,
      edad,
      telefono,
      sexo,
      gradoInstruccion,
      tallaCamisa,
      tallaPantalon,
      numeroCalzado,
      profesionOficio: profesionOficio.trim() || 'Sin Oficio',
      tipoEnfermedad,
      tratamientoMedicoActivo,
      discapacidad,
      tipoDiscapacidad: discapacidad === 'Sí' ? tipoDiscapacidad : 'Ninguna',
      alergico,
      medicamentoAlergico: alergico === 'Sí' ? medicamentoAlergico : 'Ninguno',
      
      fechaIngreso,
      cantidadPersonas: totalCantidadPersonas, // SUM INSTRUCTION RESOLVED
      direccionProcedencia: direccionProcedencia.trim(),
      estado,
      municipio,
      parroquia,
      responsableFamilia: responsableFamilia.trim() || 'No Asignado',
      telefonoResponsable,

      grupoFamiliar,
      situacionActual: situacionActual.trim(),
      imagenes,
      createdAt: editFicha ? editFicha.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    onSave(fichaCompleta);
  };

  return (
    <form onSubmit={handleSubmitForm} className="space-y-8 bg-white rounded-xl border border-slate-100 p-6 sm:p-8" id="ficha-social-form">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-5 gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-800">
            {editFicha ? 'Editar Ficha de Caracterización' : 'Nueva Ficha de Caracterización Social'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">Censo oficial para refugiados y familias damnificadas.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors shadow-2xs"
          >
            <Save className="w-4 h-4" />
            {editFicha ? 'Guardar Cambios' : 'Registrar Ficha'}
          </button>
        </div>
      </div>

      {/* BLOCK 1: DATOS JEFE O JEFA DE FAMILIA */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sky-800 font-bold text-xs uppercase tracking-wider bg-sky-50 px-3 py-1.5 rounded-lg w-max">
          <span>1. Datos del Jefe(a) de Familia</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Cédula */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Cédula de Identidad</label>
            <input
              type="text"
              required
              value={cedula}
              onChange={(e) => setCedula(e.target.value.replace(/\D/g, ''))}
              placeholder="Ej. 12345678"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Nombres */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Nombres</label>
            <input
              type="text"
              required
              value={nombres}
              onChange={(e) => setNombres(e.target.value)}
              placeholder="Nombres completos"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Apellidos */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Apellidos</label>
            <input
              type="text"
              required
              value={apellidos}
              onChange={(e) => setApellidos(e.target.value)}
              placeholder="Apellidos completos"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Fecha Nacimiento */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Fecha de Nacimiento</label>
            <input
              type="date"
              required
              value={fechaNacimiento}
              onChange={(e) => setFechaNacimiento(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Edad (Calculada) */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
              Edad Calculada
              <span className="text-[10px] font-normal text-sky-600">(Según fecha ingreso)</span>
            </label>
            <input
              type="text"
              disabled
              value={`${edad} años`}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50 text-slate-500 font-medium cursor-not-allowed"
            />
          </div>

          {/* Teléfono (+058) */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Teléfono Móvil / Fijo</label>
            <input
              type="text"
              required
              value={telefono}
              onChange={handleTelefonoJefeChange}
              placeholder="+058 (412) 123-4567"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Sexo */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Sexo</label>
            <select
              value={sexo}
              onChange={(e) => setSexo(e.target.value as any)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            >
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>

          {/* Grado Instrucción */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Grado de Instrucción</label>
            <select
              value={gradoInstruccion}
              onChange={(e) => setGradoInstruccion(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            >
              <option value="Analfabeta">Analfabeta</option>
              <option value="Sin Instrucción">Sin Instrucción</option>
              <option value="Primaria Incompleta">Primaria Incompleta</option>
              <option value="Primaria Completa">Primaria Completa</option>
              <option value="Bachiller">Bachiller / Secundaria</option>
              <option value="Técnico Medio">Técnico Medio</option>
              <option value="Universitario Incompleto">Universitario Incompleto</option>
              <option value="Universitario Completo">Universitario Completo</option>
              <option value="Postgrado">Postgrado</option>
            </select>
          </div>

          {/* Profesion / Oficio */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Profesión u Oficio</label>
            <input
              type="text"
              value={profesionOficio}
              onChange={(e) => setProfesionOficio(e.target.value)}
              placeholder="Ej. Albañil, Costurera, Ninguno"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Tallas */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Talla Camisa</label>
            <select
              value={tallaCamisa}
              onChange={(e) => setTallaCamisa(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800"
            >
              <option value="XS">XS</option>
              <option value="S">S</option>
              <option value="M">M</option>
              <option value="L">L</option>
              <option value="XL">XL</option>
              <option value="XXL">XXL</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Talla Pantalón</label>
            <input
              type="text"
              value={tallaPantalon}
              onChange={(e) => setTallaPantalon(e.target.value)}
              placeholder="Ej. 32"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Número de Calzado</label>
            <input
              type="text"
              value={numeroCalzado}
              onChange={(e) => setNumeroCalzado(e.target.value)}
              placeholder="Ej. 41"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
            />
          </div>
        </div>

        {/* Salud Sub-Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4 pt-3 border-t border-slate-50">
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Tipo de Enfermedad (Crónica/Infecciosa/Ninguna)</label>
              <input
                type="text"
                value={tipoEnfermedad}
                onChange={(e) => setTipoEnfermedad(e.target.value)}
                placeholder="Ej. Diabetes, Asma o Ninguna"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
              />
            </div>

            <div className="flex items-center gap-6">
              <label className="text-xs font-semibold text-slate-600">¿Recibe Tratamiento Médico Activo?</label>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="tratamiento"
                    checked={tratamientoMedicoActivo === 'Sí'}
                    onChange={() => setTratamientoMedicoActivo('Sí')}
                    className="accent-sky-700"
                  />
                  Sí
                </label>
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="tratamiento"
                    checked={tratamientoMedicoActivo === 'No'}
                    onChange={() => setTratamientoMedicoActivo('No')}
                    className="accent-sky-700"
                  />
                  No
                </label>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-5">
                <label className="text-xs font-semibold text-slate-600">¿Posee alguna Discapacidad?</label>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setDiscapacidad('Sí')}
                    className={`px-3 py-1 text-[11px] font-semibold rounded-md border ${
                      discapacidad === 'Sí' ? 'bg-sky-50 border-sky-300 text-sky-800' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Sí
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDiscapacidad('No');
                      setTipoDiscapacidad('');
                    }}
                    className={`px-3 py-1 text-[11px] font-semibold rounded-md border ${
                      discapacidad === 'No' ? 'bg-slate-50 border-slate-300 text-slate-700' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    No
                  </button>
                </div>
              </div>
            </div>

            {discapacidad === 'Sí' && (
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Especifique Tipo de Discapacidad</label>
                <input
                  type="text"
                  required
                  value={tipoDiscapacidad}
                  onChange={(e) => setTipoDiscapacidad(e.target.value)}
                  placeholder="Ej. Motora, Visual, Auditiva"
                  className="w-full px-3.5 py-2 border border-sky-200 rounded-lg text-sm text-slate-800 focus:border-sky-500 focus:outline-none"
                />
              </div>
            )}

            <div className="flex items-center gap-6">
              <label className="text-xs font-semibold text-slate-600">¿Sufre de Alergias?</label>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="alergico"
                    checked={alergico === 'Sí'}
                    onChange={() => setAlergico('Sí')}
                    className="accent-sky-700"
                  />
                  Sí
                </label>
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="radio"
                    name="alergico"
                    checked={alergico === 'No'}
                    onChange={() => {
                      setAlergico('No');
                      setMedicamentoAlergico('');
                    }}
                    className="accent-sky-700"
                  />
                  No
                </label>
              </div>
            </div>

            {alergico === 'Sí' && (
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Especifique Alérgenos / Medicamentos prohibidos</label>
                <input
                  type="text"
                  required
                  value={medicamentoAlergico}
                  onChange={(e) => setMedicamentoAlergico(e.target.value)}
                  placeholder="Ej. Alérgico a la Penicilina"
                  className="w-full px-3.5 py-2 border border-sky-200 rounded-lg text-sm text-slate-800 focus:border-sky-500 focus:outline-none"
                />
              </div>
            )}
          </div>

        </div>
      </div>

      {/* BLOCK 2: EQUIPO RESPONSABLE DE FAMILIA & GEOPOLITICA */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sky-800 font-bold text-xs uppercase tracking-wider bg-sky-50 px-3 py-1.5 rounded-lg w-max">
          <span>2. Información de Ingreso y Geopolítica</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Fecha Ingreso */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Fecha de Ingreso al Refugio / Censo</label>
            <input
              type="date"
              required
              value={fechaIngreso}
              onChange={(e) => setFechaIngreso(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* Cantidad Personas (Sum) */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1 flex items-center gap-1.5">
              Cantidad de Personas
              <span className="text-[10px] text-emerald-600 font-normal">(Autocalculado)</span>
            </label>
            <input
              type="text"
              disabled
              value={`${totalCantidadPersonas} personas (${1} Jefe + ${grupoFamiliar.length} Carga)`}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm bg-emerald-50 text-emerald-800 font-semibold cursor-not-allowed"
            />
          </div>

          {/* Dirección procedencia */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Dirección Exacta de Procedencia</label>
            <input
              type="text"
              required
              value={direccionProcedencia}
              onChange={(e) => setDireccionProcedencia(e.target.value)}
              placeholder="Ej. Calle Principal, Barrio El Triunfo, Casa Nro 4"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
            />
          </div>

          {/* Estado con opción de agregar */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-600">Estado</label>
              <button
                type="button"
                onClick={() => handleOpenAddModal('estado')}
                className="text-[10px] font-bold text-sky-700 hover:text-sky-800 flex items-center gap-0.5"
              >
                <Plus className="w-2.5 h-2.5" /> Agregar Estado
              </button>
            </div>
            <select
              required
              value={estado}
              onChange={handleEstadoChange}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800 focus:outline-none"
            >
              <option value="">-- Seleccione Estado --</option>
              {Object.keys(division.estados).map((estName) => (
                <option key={estName} value={estName}>{estName}</option>
              ))}
            </select>
          </div>

          {/* Municipio con opción de agregar */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-600">Municipio</label>
              <button
                type="button"
                disabled={!estado}
                onClick={() => handleOpenAddModal('municipio')}
                className="text-[10px] font-bold text-sky-700 hover:text-sky-800 flex items-center gap-0.5 disabled:text-slate-300 disabled:cursor-not-allowed"
              >
                <Plus className="w-2.5 h-2.5" /> Agregar Municipio
              </button>
            </div>
            <select
              required
              value={municipio}
              onChange={handleMunicipioChange}
              disabled={!estado}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800 focus:outline-none disabled:bg-slate-50 disabled:cursor-not-allowed"
            >
              <option value="">-- Seleccione Municipio --</option>
              {estado &&
                Object.keys(division.estados[estado]?.municipios || {}).map((munName) => (
                  <option key={munName} value={munName}>{munName}</option>
                ))}
            </select>
          </div>

          {/* Parroquia con opción de agregar */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-600">Parroquia</label>
              <button
                type="button"
                disabled={!estado || !municipio}
                onClick={() => handleOpenAddModal('parroquia')}
                className="text-[10px] font-bold text-sky-700 hover:text-sky-800 flex items-center gap-0.5 disabled:text-slate-300 disabled:cursor-not-allowed"
              >
                <Plus className="w-2.5 h-2.5" /> Agregar Parroquia
              </button>
            </div>
            <select
              required
              value={parroquia}
              onChange={(e) => setParroquia(e.target.value)}
              disabled={!estado || !municipio}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-sm text-slate-800 focus:outline-none disabled:bg-slate-50 disabled:cursor-not-allowed"
            >
              <option value="">-- Seleccione Parroquia --</option>
              {estado &&
                municipio &&
                (division.estados[estado]?.municipios[municipio] || []).map((parrName) => (
                  <option key={parrName} value={parrName}>{parrName}</option>
                ))}
            </select>
          </div>

          {/* Responsable de evaluar */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Responsable Evaluador (Equipo)</label>
            <input
              type="text"
              required
              value={responsableFamilia}
              onChange={(e) => setResponsableFamilia(e.target.value)}
              placeholder="Nombre del brigadista/coordinador"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
            />
          </div>

          {/* Teléfono Responsable */}
          <div>
            <label className="block text-xs font-semibold text-slate-600 mb-1">Teléfono Responsable Evaluador</label>
            <input
              type="text"
              required
              value={telefonoResponsable}
              onChange={handleTelefonoResponsableChange}
              placeholder="+058 (424) 765-4321"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-lg text-sm text-slate-800"
            />
          </div>
        </div>
      </div>

      {/* BLOCK 3: DATOS GRUPO FAMILIAR */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sky-800 font-bold text-xs uppercase tracking-wider bg-sky-50 px-3 py-1.5 rounded-lg w-max">
          <span>3. Carga de Célula / Grupo Familiar ({grupoFamiliar.length} cargas registradas)</span>
        </div>

        {/* Temporary inputs panel to add a family member */}
        <div className="bg-slate-50/50 rounded-xl p-5 border border-slate-100 space-y-4">
          <h4 className="font-semibold text-xs text-slate-700 uppercase tracking-wide">Cargar Nuevo Integrante Familiar</h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            
            {/* Nombres */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Nombres y Apellidos</label>
              <input
                type="text"
                value={famNombres}
                onChange={(e) => setFamNombres(e.target.value)}
                placeholder="Ej. María Valentina Pérez"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800 focus:outline-none focus:border-sky-500"
              />
            </div>

            {/* Parentesco */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Parentesco</label>
              <select
                value={famParentezco}
                onChange={(e) => setFamParentezco(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800 focus:outline-none"
              >
                <option value="Hijo/a">Hijo/a</option>
                <option value="Esposo/a">Esposo/a</option>
                <option value="Hermano/a">Hermano/a</option>
                <option value="Padre">Padre</option>
                <option value="Madre">Madre</option>
                <option value="Abuelo/a">Abuelo/a</option>
                <option value="Nieto/a">Nieto/a</option>
                <option value="Sobrino/a">Sobrino/a</option>
                <option value="Otro">Otro Familiar</option>
              </select>
            </div>

            {/* Edad */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Edad</label>
              <input
                type="number"
                value={famEdad}
                onChange={(e) => setFamEdad(e.target.value)}
                placeholder="Edad en años"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800 focus:outline-none"
              />
            </div>

            {/* Sexo */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Sexo</label>
              <select
                value={famSexo}
                onChange={(e) => setFamSexo(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              >
                <option value="Masculino">Masculino</option>
                <option value="Femenino">Femenino</option>
                <option value="Otro">Otro</option>
              </select>
            </div>

            {/* Camisa */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Talla Camisa</label>
              <select
                value={famCamisa}
                onChange={(e) => setFamCamisa(e.target.value)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              >
                <option value="XS">XS</option>
                <option value="S">S</option>
                <option value="M">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option>
              </select>
            </div>

            {/* Calzado */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Número Calzado</label>
              <input
                type="text"
                value={famCalzado}
                onChange={(e) => setFamCalzado(e.target.value)}
                placeholder="Ej. 38"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              />
            </div>

            {/* Pantalon */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Talla Pantalón</label>
              <input
                type="text"
                value={famPantalon}
                onChange={(e) => setFamPantalon(e.target.value)}
                placeholder="Ej. 28"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              />
            </div>

            {/* Enfermedad */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Enfermedad (Si aplica)</label>
              <input
                type="text"
                value={famEnfermedad}
                onChange={(e) => setFamEnfermedad(e.target.value)}
                placeholder="Diabetes, Asma o Ninguna"
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              />
            </div>

            {/* Alergico */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">¿Es Alérgico?</label>
              <select
                value={famAlergico}
                onChange={(e) => setFamAlergico(e.target.value as any)}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-md text-xs text-slate-800"
              >
                <option value="No">No</option>
                <option value="Sí">Sí</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={handleAddFamiliar}
              className="flex items-center gap-1.5 bg-sky-700 hover:bg-sky-800 text-white font-bold text-xs px-4 py-2 rounded-lg transition-colors shadow-2xs"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Agregar Integrante
            </button>
          </div>
        </div>

        {/* Familiar table listing */}
        {grupoFamiliar.length > 0 ? (
          <div className="border border-slate-100 rounded-xl overflow-hidden shadow-2xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider border-b border-slate-100">
                  <th className="py-3 px-4">Parentezco</th>
                  <th className="py-3 px-4">Nombres y Apellidos</th>
                  <th className="py-3 px-4">Edad</th>
                  <th className="py-3 px-4">Sexo</th>
                  <th className="py-3 px-4">Tallas (Calz/Cam/Pant)</th>
                  <th className="py-3 px-4">Enfermedad</th>
                  <th className="py-3 px-4 text-center">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {grupoFamiliar.map((fam) => (
                  <tr key={fam.id} className="hover:bg-slate-50/55 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-700">{fam.parentezco}</td>
                    <td className="py-3 px-4 text-slate-600">{fam.nombresApellidos}</td>
                    <td className="py-3 px-4 text-slate-600">{fam.edad} años</td>
                    <td className="py-3 px-4 text-slate-500">{fam.sexo}</td>
                    <td className="py-3 px-4 text-slate-500">
                      Z: <strong className="text-slate-700">{fam.numeroCalzado}</strong> | C: <strong className="text-slate-700">{fam.tallaCamisa}</strong> | P: <strong className="text-slate-700">{fam.tallaPantalon}</strong>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${fam.tipoEnfermedad !== 'Ninguna' ? 'bg-amber-50 text-amber-800' : 'bg-slate-100 text-slate-600'}`}>
                        {fam.tipoEnfermedad}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        type="button"
                        onClick={() => handleRemoveFamiliar(fam.id)}
                        className="text-rose-500 hover:text-rose-700 p-1 rounded-md hover:bg-rose-50 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-4 border border-slate-100 border-dashed rounded-lg text-center text-xs text-slate-400 italic">
            No se han cargado integrantes en el grupo familiar secundario. El Jefe de familia cuenta como única persona registrada.
          </div>
        )}
      </div>

      {/* BLOCK 4: OBSERVACIONES / DETALLES */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sky-800 font-bold text-xs uppercase tracking-wider bg-sky-50 px-3 py-1.5 rounded-lg w-max">
          <span>4. Situación Actual y Detalles Colectivos</span>
        </div>
        <div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Descripción Detallada de la Situación Actual</label>
          <textarea
            value={situacionActual}
            onChange={(e) => setSituacionActual(e.target.value)}
            rows={4}
            placeholder="Describa el estatus de la vivienda, necesidad de reubicación, estatus socio-económico crítico, etc."
            className="w-full px-3.5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-none focus:border-sky-500 transition-colors resize-y"
          />
        </div>
      </div>

      {/* BLOCK 5: MEMORIA FOTOGRÁFICA WITH AUTOMATIC SIZE REDUCTION (< 1MB) */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sky-800 font-bold text-xs uppercase tracking-wider bg-sky-50 px-3 py-1.5 rounded-lg w-max">
          <span>5. Memoria Fotográfica Oficial</span>
        </div>

        <div className="space-y-3">
          <p className="text-xs text-slate-400">
            Sube fotografías del siniestro, censo, o grupo familiar. El sistema optimiza y reduce el peso automáticamente para guardarlas de manera eficiente (máximo 1MB por imagen).
          </p>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2.5 px-4 rounded-lg cursor-pointer transition-colors">
              <Camera className="w-4 h-4 text-slate-500" />
              Subir Imágenes (JPG, PNG, WEBP)
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
            {imagenes.length > 0 && (
              <span className="text-xs text-slate-500 font-medium">{imagenes.length} foto(s) cargada(s)</span>
            )}
          </div>

          {imageError && (
            <p className="text-xs text-rose-600 font-semibold flex items-center gap-1">
              <Info className="w-3.5 h-3.5" />
              {imageError}
            </p>
          )}

          {imagenes.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 pt-3">
              {imagenes.map((base64, idx) => (
                <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 bg-slate-50 shadow-2xs aspect-4/3">
                  <img src={base64} alt={`Refugiado ${idx + 1}`} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="bg-white/90 text-rose-600 p-2 rounded-full hover:bg-white transition-transform duration-200 hover:scale-105"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <span className="absolute bottom-1 right-1.5 bg-black/60 text-[8px] text-white font-medium px-1.5 py-0.5 rounded-sm">
                    FOTO {idx + 1}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* FOOTER ACTIONS */}
      <div className="flex justify-end gap-3 pt-6 border-t border-slate-100">
        <button
          type="button"
          onClick={onCancel}
          className="px-5 py-2.5 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors shadow-sm"
        >
          <Save className="w-4 h-4" />
          {editFicha ? 'Guardar Cambios de Ficha' : 'Completar Registro de Ficha'}
        </button>
      </div>

      {/* --- INLINE ADDITION MODALS (STATE / MUN / PAR) --- */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-lg max-w-sm w-full animate-in fade-in zoom-in duration-200">
            <h4 className="font-bold text-slate-800 text-sm flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-sky-700" />
              Agregar {modalOpen === 'estado' ? 'Estado' : modalOpen === 'municipio' ? 'Municipio' : 'Parroquia'}
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              {modalOpen === 'estado' && 'Ingrese el nombre del nuevo estado federativo de Venezuela.'}
              {modalOpen === 'municipio' && `Se agregará el municipio al estado activo: ${estado}.`}
              {modalOpen === 'parroquia' && `Se agregará la parroquia al municipio activo: ${municipio}.`}
            </p>
            <input
              type="text"
              autoFocus
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder={`Nombre de ${modalOpen === 'estado' ? 'Estado' : modalOpen === 'municipio' ? 'Municipio' : 'Parroquia'}`}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm mt-4 focus:outline-none focus:border-sky-500"
            />
            <div className="flex justify-end gap-2 mt-5">
              <button
                type="button"
                onClick={() => setModalOpen(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveCustomItem}
                className="px-3 py-1.5 text-xs font-bold text-white bg-sky-700 hover:bg-sky-800 rounded-lg"
              >
                Agregar
              </button>
            </div>
          </div>
        </div>
      )}

    </form>
  );
}
