/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { 
  Download, Upload, RotateCcw, CheckCircle2, AlertCircle, RefreshCw, 
  FileText, Cloud, CloudUpload, CloudDownload, Trash2, Link2, UserCheck, LogOut 
} from 'lucide-react';
import { FichaSocial } from '../types';
import { User } from 'firebase/auth';
import { 
  getOrCreateFolder, uploadFileToFolder, listFilesInFolder, 
  downloadFileAsText, deleteDriveFile 
} from '../utils/googleDriveHelper';

interface MantenimientoProps {
  fichas: FichaSocial[];
  onRestoreBackup: (allFichas: FichaSocial[]) => void;
  googleUser: User | null;
  googleToken: string | null;
  onGoogleSignIn: () => void;
  onGoogleSignOut: () => void;
}

export default function Mantenimiento({
  fichas,
  onRestoreBackup,
  googleUser,
  googleToken,
  onGoogleSignIn,
  onGoogleSignOut
}: MantenimientoProps) {
  const jsonFileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Cloud backup states
  const [driveBackups, setDriveBackups] = useState<any[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [uploadingToDrive, setUploadingToDrive] = useState(false);

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 8000);
  };

  // Fetch backups from Google Drive folder
  const fetchDriveBackups = async (token: string) => {
    setDriveLoading(true);
    try {
      const folderId = await getOrCreateFolder(token, 'Censo_Damnificados_Backups');
      const files = await listFilesInFolder(token, folderId);
      // Filter only JSON backups
      setDriveBackups(files.filter(f => f.name.endsWith('.json')));
    } catch (err: any) {
      console.error('Error fetching drive backups:', err);
      showMessage('error', `Error al listar respaldos de Google Drive: ${err.message}`);
    } finally {
      setDriveLoading(false);
    }
  };

  useEffect(() => {
    if (googleToken) {
      fetchDriveBackups(googleToken);
    } else {
      setDriveBackups([]);
    }
  }, [googleToken]);

  // 1. Database Backup (Download JSON)
  const handleDatabaseBackup = () => {
    try {
      const dataStr = JSON.stringify(fichas, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `Respaldo_Fichas_Sociales_${new Date().toISOString().split('T')[0]}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      showMessage('success', 'Respaldo Completo (.json) creado e instalado con éxito en sus descargas locales.');
    } catch (e) {
      showMessage('error', 'Error al realizar el respaldo físico de la base de datos.');
    }
  };

  // 2. Database Restore (Upload JSON)
  const handleDatabaseRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const result = event.target?.result;
        if (typeof result !== 'string') throw new Error('Contenido de archivo ilegible');
        
        const restoredFichas = JSON.parse(result);
        if (!Array.isArray(restoredFichas)) throw new Error('La estructura de datos de respaldo debe ser un listado de fichas.');

        if (restoredFichas.length > 0) {
          const sample = restoredFichas[0];
          if (!('cedula' in sample) || !('nombres' in sample) || !('grupoFamiliar' in sample)) {
            throw new Error('Las propiedades del censo no corresponden con el formato de caracterización social.');
          }
        }

        onRestoreBackup(restoredFichas);
        showMessage('success', `Restauración Exitosa: Se han cargado ${restoredFichas.length} registros desde el archivo de copia de seguridad.`);
      } catch (err) {
        showMessage('error', `Fallo al procesar restauración: ${(err as Error).message}`);
      } finally {
        setLoading(false);
        if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
      }
    };
    reader.onerror = () => {
      setLoading(false);
      showMessage('error', 'Error al leer el archivo físico de respaldo.');
    };
    reader.readAsText(file);
  };

  // 3. Create Cloud Backup (Upload JSON to Google Drive)
  const handleCloudBackup = async () => {
    if (!googleToken) return;
    setUploadingToDrive(true);
    try {
      const folderId = await getOrCreateFolder(googleToken, 'Censo_Damnificados_Backups');
      const dataStr = JSON.stringify(fichas, null, 2);
      
      // Formatting file name
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
      const filename = `Respaldo_Censo_Damnificados_${dateStr}_${timeStr}.json`;
      
      await uploadFileToFolder(googleToken, folderId, filename, 'application/json', dataStr);
      showMessage('success', `Copia en la nube guardada con éxito: "${filename}"`);
      await fetchDriveBackups(googleToken);
    } catch (err: any) {
      console.error('Error uploading to drive:', err);
      showMessage('error', `No se pudo guardar la copia en Drive: ${err.message}`);
    } finally {
      setUploadingToDrive(false);
    }
  };

  // 4. Restore Cloud Backup (Download and load JSON)
  const handleCloudRestore = async (fileId: string, fileName: string) => {
    if (!googleToken) return;
    const confirmed = window.confirm(`¿Está seguro de que desea restaurar el respaldo "${fileName}" desde Google Drive?\n\n¡ADVERTENCIA!: Esto reemplazará todos los registros del censo local actualmente en memoria de manera irreversible.`);
    if (!confirmed) return;

    setLoading(true);
    try {
      const content = await downloadFileAsText(googleToken, fileId);
      const restoredFichas = JSON.parse(content);
      
      if (!Array.isArray(restoredFichas)) {
        throw new Error('La estructura de datos de respaldo debe ser un listado de fichas.');
      }

      if (restoredFichas.length > 0) {
        const sample = restoredFichas[0];
        if (!('cedula' in sample) || !('nombres' in sample) || !('grupoFamiliar' in sample)) {
          throw new Error('Las propiedades del censo no corresponden con el formato de caracterización social.');
        }
      }

      onRestoreBackup(restoredFichas);
      showMessage('success', `Restauración Exitosa: Se han cargado ${restoredFichas.length} registros desde Google Drive.`);
    } catch (err: any) {
      console.error('Error restoring from cloud:', err);
      showMessage('error', `Error al restaurar desde Google Drive: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 5. Delete Cloud Backup from Drive
  const handleCloudDelete = async (fileId: string, fileName: string) => {
    if (!googleToken) return;
    const confirmed = window.confirm(`¿Está seguro de que desea eliminar permanentemente el archivo de respaldo "${fileName}" de su Google Drive?`);
    if (!confirmed) return;

    setDriveLoading(true);
    try {
      await deleteDriveFile(googleToken, fileId);
      showMessage('success', `Respaldo "${fileName}" eliminado correctamente de Google Drive.`);
      await fetchDriveBackups(googleToken);
    } catch (err: any) {
      console.error('Error deleting file:', err);
      showMessage('error', `Error al eliminar archivo: ${err.message}`);
    } finally {
      setDriveLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8" id="panel-mantenimiento">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-800 uppercase tracking-tight">Mantenimiento y Respaldo de Datos</h2>
          <p className="text-xs text-slate-500 mt-1">Crea copias de resguardo locales y en la nube de Google Drive para salvaguardar el censo social.</p>
        </div>
        <div className="mt-2 sm:mt-0 flex items-center gap-2">
          {googleUser && (
            <div className="bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-md text-[10px] font-bold text-emerald-600 uppercase flex items-center gap-1">
              <Cloud className="w-3.5 h-3.5 shrink-0" />
              <span>Drive: Conectado</span>
            </div>
          )}
          <div className="bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-md text-[11px] font-bold text-indigo-600 uppercase">
            Estado Fichas: {fichas.length > 0 ? 'DATOS SEGUROS' : 'CENSO VACÍO'}
          </div>
        </div>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 text-xs sm:text-sm ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="font-bold">{message.type === 'success' ? 'Operación Exitosa' : 'Atención'}</p>
            <p className="mt-1 leading-relaxed text-slate-600 font-medium">{message.text}</p>
          </div>
        </div>
      )}

      {/* CORE UTILITY BOXES (3 Columns) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* DOWNLOAD BACKUP BLOCK */}
        <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700 mb-4 shadow-3xs">
              <Download className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Copia de Seguridad Local</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Descarga un archivo encriptado en formato estructurado JSON conteniendo el censo social completo, los jefes de familia, integrantes, situaciones individuales y la memoria fotográfica vinculada.
            </p>
          </div>
          
          <div className="mt-6">
            <button
              onClick={handleDatabaseBackup}
              disabled={fichas.length === 0}
              className={`w-full flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs uppercase tracking-wide rounded-lg border transition-all shadow-3xs transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer ${
                fichas.length === 0
                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed shadow-none'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700'
              }`}
              id="btn-crear-respaldo-json"
            >
              <Download className="w-4 h-4 text-white shrink-0" />
              <span>Descargar (.json)</span>
            </button>
          </div>
        </div>

        {/* UPLOAD RESTORE BLOCK */}
        <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700 mb-4 shadow-3xs">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Restauración Local</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Sube un archivo de respaldo JSON generado previamente en esta plataforma para restaurar la totalidad de las fichas de caracterización social. <strong>Advertencia:</strong> Reemplazará los registros actualmente en memoria.
            </p>
          </div>
          
          <div className="mt-6">
            <label className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wide rounded-lg border border-emerald-700 transition-all shadow-3xs transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer text-center">
              <RefreshCw className={`w-4 h-4 text-white shrink-0 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Cargando...' : 'Restaurar (.json)'}</span>
              <input
                ref={jsonFileInputRef}
                type="file"
                accept=".json"
                onChange={handleDatabaseRestore}
                className="hidden"
                disabled={loading}
              />
            </label>
          </div>
        </div>

        {/* GOOGLE DRIVE CLOUD STORAGE BLOCK */}
        <div className="p-6 rounded-xl border border-emerald-200 bg-emerald-50/20 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800 mb-4 shadow-3xs">
              <Cloud className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Resguardo en la Nube (Google Drive)</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Almacene de manera segura las copias de seguridad del censo nacional directamente en su Google Drive personal dentro de la carpeta automatizada <code className="bg-slate-100 text-emerald-800 px-1 py-0.5 rounded font-mono">Censo_Damnificados_Backups</code>.
            </p>

            {/* Google Authentication States */}
            {!googleUser ? (
              <div className="mt-5 p-4 bg-white rounded-lg border border-slate-200">
                <p className="text-[11px] text-slate-600 font-medium mb-3 leading-relaxed">
                  Debe enlazar su cuenta de Google para habilitar el almacenamiento en la nube y sincronizar copias.
                </p>
                {/* Google Sign In Button */}
                <button 
                  onClick={onGoogleSignIn}
                  className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white border border-slate-300 hover:border-slate-400 rounded-md shadow-2xs hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
                >
                  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-4 h-4 shrink-0">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                  </svg>
                  <span>Vincular Cuenta de Google</span>
                </button>
              </div>
            ) : (
              <div className="mt-4 p-3 bg-white rounded-lg border border-emerald-100 flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {googleUser.photoURL ? (
                      <img src={googleUser.photoURL} alt="Avatar" className="w-7 h-7 rounded-full border border-emerald-200" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-emerald-100 flex items-center justify-center font-bold text-emerald-800 text-xs">
                        {googleUser.displayName?.charAt(0) || 'G'}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-[11px] font-bold text-slate-800 truncate leading-none">{googleUser.displayName}</p>
                      <p className="text-[9px] text-slate-500 truncate mt-0.5">{googleUser.email}</p>
                    </div>
                  </div>
                  <button 
                    onClick={onGoogleSignOut} 
                    className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Desvincular Cuenta"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Cloud Backups Area */}
                <div className="border-t border-slate-100 pt-2.5">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">COPIAS EN GOOGLE DRIVE:</span>
                    <button 
                      onClick={() => googleToken && fetchDriveBackups(googleToken)} 
                      disabled={driveLoading}
                      className="text-[9px] text-blue-600 hover:text-blue-800 font-semibold uppercase flex items-center gap-0.5 cursor-pointer"
                    >
                      <RefreshCw className={`w-2.5 h-2.5 ${driveLoading ? 'animate-spin' : ''}`} />
                      <span>Actualizar</span>
                    </button>
                  </div>

                  {driveLoading && driveBackups.length === 0 ? (
                    <div className="py-4 text-center text-[10px] text-slate-400">
                      <span>Cargando respaldos de Drive...</span>
                    </div>
                  ) : driveBackups.length === 0 ? (
                    <div className="py-4 text-center text-[10px] text-slate-400 border border-dashed border-slate-200 rounded">
                      <span>No se encontraron copias en Drive.</span>
                    </div>
                  ) : (
                    <div className="max-h-28 overflow-y-auto space-y-1.5 border border-slate-100 rounded p-1.5 bg-slate-50/50">
                      {driveBackups.map((file) => (
                        <div key={file.id} className="flex items-center justify-between text-[10px] bg-white p-2 rounded border border-slate-100 hover:border-emerald-200 shadow-3xs">
                          <div className="min-w-0 flex-1 pr-2">
                            <p className="font-medium text-slate-700 truncate" title={file.name}>{file.name}</p>
                            <p className="text-[8px] text-slate-400 mt-0.5">
                              {new Date(file.createdTime).toLocaleString()} • {(file.size / 1024).toFixed(1)} KB
                            </p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => handleCloudRestore(file.id, file.name)}
                              className="p-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded transition-colors cursor-pointer"
                              title="Restaurar este respaldo"
                            >
                              <CloudDownload className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => handleCloudDelete(file.id, file.name)}
                              className="p-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded transition-colors cursor-pointer"
                              title="Eliminar de Drive"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          
          <div className="mt-6">
            <button
              onClick={handleCloudBackup}
              disabled={!googleToken || fichas.length === 0 || uploadingToDrive}
              className={`w-full flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs uppercase tracking-wide rounded-lg border transition-all shadow-3xs transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer ${
                !googleToken || fichas.length === 0 || uploadingToDrive
                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed shadow-none'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 shadow-emerald-100'
              }`}
            >
              <CloudUpload className={`w-4 h-4 text-white shrink-0 ${uploadingToDrive ? 'animate-pulse' : ''}`} />
              <span>{uploadingToDrive ? 'Subiendo...' : 'Subir Copia a Drive'}</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
