/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import { useState } from 'react';
import { Users, User, Heart, Compass, ShieldAlert, BarChart3, PieChart, ShoppingBag } from 'lucide-react';
import { FichaSocial } from '../types';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell,
  PieChart as RePieChart, Pie
} from 'recharts';

interface DashboardProps {
  fichas: FichaSocial[];
  stats: any;
}

// Custom Tooltip for Recharts that matches our layout design beautifully
const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const dataName = payload[0].payload.name || payload[0].name;
    return (
      <div className="bg-slate-900 text-white p-3 rounded-lg border border-slate-800 shadow-xl text-[11px] font-semibold">
        <p className="text-slate-400 uppercase tracking-wider text-[9px] mb-1">{dataName}</p>
        <p className="text-xs font-black text-white">
          {payload[0].value} <span className="text-slate-400 font-normal">Casos / Personas</span>
        </p>
      </div>
    );
  }
  return null;
};

export default function Dashboard({ fichas, stats }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<'territorio' | 'demografia' | 'logistica'>('territorio');

  if (fichas.length === 0) {
    return (
      <div className="bg-slate-50 border border-slate-200 border-dashed rounded-xl p-12 text-center" id="dashboard-empty">
        <ShieldAlert className="w-12 h-12 text-slate-400 mx-auto mb-4" />
        <h3 className="text-slate-800 font-semibold text-base">Falta Cargar Información</h3>
        <p className="text-slate-500 text-sm max-w-sm mx-auto mt-1">
          No hay fichas de damnificados registradas en el sistema. Registra un nuevo caso manualmente o carga datos por Excel para visualizar los gráficos interactivos de gestión.
        </p>
      </div>
    );
  }

  // 1. Data parsing for charts
  // States
  const estadosData = Object.entries(stats.distribucionEstados || {})
    .map(([name, val]) => ({ name, value: Number(val) }))
    .sort((a, b) => b.value - a.value);

  // Age ranges (Jefes + Familiares)
  const ageData = [
    { name: 'Niños (0-11)', value: stats.rangosEdad?.ninos || 0, color: '#38bdf8' },
    { name: 'Jóvenes (12-17)', value: stats.rangosEdad?.jovenes || 0, color: '#6366f1' },
    { name: 'Adultos (18-59)', value: stats.rangosEdad?.adultos || 0, color: '#0d6e8b' },
    { name: 'Adultos Mayores (60+)', value: stats.rangosEdad?.ancianos || 0, color: '#f43f5e' }
  ];

  // Genders
  const sexData = [
    { name: 'Femenino', value: stats.distribucionSexo?.Femenino || 0, color: '#ec4899' },
    { name: 'Masculino', value: stats.distribucionSexo?.Masculino || 0, color: '#0284c7' },
    { name: 'Otro', value: stats.distribucionSexo?.Otro || 0, color: '#a855f7' }
  ];
  const totalSexValues = sexData.reduce((acc, curr) => acc + curr.value, 0) || 1;

  // Logistics: Shirt and Shoe sizes (Jefe + Grupo Familiar)
  const getLogisticsStats = () => {
    const shirts: Record<string, number> = {};
    const shoes: Record<string, number> = {};

    fichas.forEach(f => {
      // Jefe
      if (f.tallaCamisa) shirts[f.tallaCamisa] = (shirts[f.tallaCamisa] || 0) + 1;
      if (f.numeroCalzado) shoes[f.numeroCalzado] = (shoes[f.numeroCalzado] || 0) + 1;

      // Fam
      f.grupoFamiliar.forEach(fam => {
        if (fam.tallaCamisa) shirts[fam.tallaCamisa] = (shirts[fam.tallaCamisa] || 0) + 1;
        if (fam.numeroCalzado) shoes[fam.numeroCalzado] = (shoes[fam.numeroCalzado] || 0) + 1;
      });
    });

    const topShirts = Object.entries(shirts)
      .map(([size, count]) => ({ size, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    const topShoes = Object.entries(shoes)
      .map(([size, count]) => ({ size, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return { topShirts, topShoes };
  };

  const logistics = getLogisticsStats();

  return (
    <div className="space-y-6" id="dashboard-container">
      
      {/* 1. TOP CARDS PANEL */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="dashboard-metrics-grid">
        
        {/* Card 1: Total Caracterizados */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
            <span>Total Caracterizados</span>
            <Users className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-3xl font-black text-slate-800 mt-1.5">{stats.totalPersonas || 0}</div>
          <div className="mt-2 text-[11px] text-emerald-600 font-bold flex items-center gap-1">
            <span>+12% este mes</span> 
            <span className="text-slate-400 font-normal">vs. período anterior</span>
          </div>
        </div>

        {/* Card 2: Jefes de Familia */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
            <span>Jefes de Familia</span>
            <User className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-3xl font-black text-slate-800 mt-1.5">{fichas.length}</div>
          <div className="mt-3.5 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-blue-500 rounded-full transition-all duration-500" 
              style={{ width: `${Math.min(100, Math.max(10, (fichas.length / (stats.totalPersonas || 1)) * 100))}%` }}
            />
          </div>
        </div>

        {/* Card 3: Cargas Familiares */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
            <span>Cargas Familiares</span>
            <Users className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-3xl font-black text-slate-800 mt-1.5">{Math.max(0, stats.totalPersonas - fichas.length)}</div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium">
            Promedio: <strong className="text-slate-700 font-bold">{(stats.totalPersonas / (fichas.length || 1)).toFixed(1)} personas/familia</strong>
          </div>
        </div>

        {/* Card 4: Atención Vulnerable */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
            <span>Atención Vulnerable</span>
            <Heart className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <div className="text-3xl font-black text-rose-600 mt-1.5">{stats.conEnfermedad + stats.conDiscapacidad}</div>
          <div className="mt-2 text-[11px] text-rose-500 font-bold">
            Casos Críticos Detectados
          </div>
        </div>

      </div>

      {/* 2. TABBED GRAPHICAL ANALYTICS PANEL */}
      <div className="bg-white border border-slate-100 rounded-xl shadow-xs overflow-hidden">
        
        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-100 bg-slate-50/50 p-1 gap-1">
          <button
            onClick={() => setActiveTab('territorio')}
            className={`flex items-center gap-2 py-2.5 px-4 rounded-lg font-medium text-xs transition-all ${
              activeTab === 'territorio'
                ? 'bg-white text-sky-800 shadow-2xs border border-slate-100/50'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/40'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Distribución Territorial
          </button>
          <button
            onClick={() => setActiveTab('demografia')}
            className={`flex items-center gap-2 py-2.5 px-4 rounded-lg font-medium text-xs transition-all ${
              activeTab === 'demografia'
                ? 'bg-white text-sky-800 shadow-2xs border border-slate-100/50'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/40'
            }`}
          >
            <PieChart className="w-3.5 h-3.5" />
            Vulnerabilidad y Demografía
          </button>
          <button
            onClick={() => setActiveTab('logistica')}
            className={`flex items-center gap-2 py-2.5 px-4 rounded-lg font-medium text-xs transition-all ${
              activeTab === 'logistica'
                ? 'bg-white text-sky-800 shadow-2xs border border-slate-100/50'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100/40'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            Suministros y Logística
          </button>
        </div>

        {/* Tab contents */}
        <div className="p-6">
          {/* TAB 1: TERRITORIO */}
          {activeTab === 'territorio' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              
              {/* Vertical dynamic bar chart using Recharts */}
              <div className="lg:col-span-2 space-y-4 flex flex-col justify-between">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">Familias Afectadas por Estado</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Métrica territorial agrupada jerárquicamente de Venezuela.</p>
                </div>

                <div className="pt-4 h-72 w-full" id="chart-territorio">
                  {estadosData.length === 0 ? (
                    <div className="w-full h-full flex items-center justify-center text-slate-400 italic text-xs">Sin datos geográficos</div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={estadosData} margin={{ top: 20, right: 10, left: -20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fill: '#64748b', fontSize: 10, fontWeight: 600 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <YAxis 
                          tick={{ fill: '#64748b', fontSize: 10 }}
                          axisLine={false}
                          tickLine={false}
                        />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f8fafc' }} />
                        <Bar dataKey="value" fill="#3b82f6" radius={[6, 6, 0, 0]} maxBarSize={50}>
                          {estadosData.map((entry, index) => (
                            <Cell 
                              key={`cell-${index}`} 
                              fill={index === 0 ? '#1d4ed8' : '#3b82f6'} 
                              className="transition-all duration-300 hover:opacity-90"
                            />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>

              {/* Geographical bento table summary */}
              <div className="bg-slate-50/70 rounded-xl p-5 border border-slate-200/60 flex flex-col justify-between">
                <div>
                  <h5 className="font-semibold text-slate-800 text-xs uppercase tracking-wider mb-3">Zonas con Mayor Incidencia</h5>
                  <div className="space-y-3">
                    {estadosData.slice(0, 4).map((d) => {
                      // Find most affected parish inside the state
                      const stateFichas = fichas.filter(f => f.estado === d.name);
                      const parishesCount: Record<string, number> = {};
                      stateFichas.forEach(f => {
                        if (f.parroquia) parishesCount[f.parroquia] = (parishesCount[f.parroquia] || 0) + 1;
                      });
                      const topParish = Object.entries(parishesCount).sort((a,b) => b[1]-a[1])[0]?.[0] || 'N/A';

                      return (
                        <div key={d.name} className="flex justify-between items-start py-2 border-b border-slate-200/50 text-xs">
                          <div>
                            <p className="font-semibold text-slate-700">{d.name}</p>
                            <p className="text-[10px] text-slate-400 mt-0.5">Parroquia crítica: {topParish}</p>
                          </div>
                          <span className="bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded-md font-bold text-[10px] border border-blue-100">{d.value} Casos</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 leading-relaxed mt-4 pt-4 border-t border-slate-200/50">
                  ⚠️ <strong>Nota:</strong> Los datos geográficos anteriores reflejan el censo de damnificados activo. Use las listas de selección inteligente del formulario de ingreso para preservar la jerarquía nacional de división territorial.
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: DEMOGRAFIA */}
          {activeTab === 'demografia' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Interactive Horizontal Bar Chart for Age Ranges */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">Distribución de Edades de Damnificados</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Segmentación etaria del censo total (Jefes de Familia + Cargas).</p>
                </div>

                <div className="h-64 pt-2" id="chart-edades">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={ageData}
                      layout="vertical"
                      margin={{ top: 10, right: 20, left: 30, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                      <XAxis type="number" tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis 
                        dataKey="name" 
                        type="category" 
                        tick={{ fill: '#475569', fontSize: 10, fontWeight: 500 }}
                        axisLine={{ stroke: '#cbd5e1' }}
                        tickLine={false}
                      />
                      <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f8fafc' }} />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                        {ageData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Gender representation / Recharts Donut Chart */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">Distribución por Género</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Participación censada para distribución equitativa de insumos de género.</p>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-8 pt-2">
                  
                  {/* Interactive Recharts Donut Chart */}
                  <div className="relative w-40 h-40 shrink-0 mx-auto sm:mx-0" id="chart-genero">
                    <ResponsiveContainer width="100%" height="100%">
                      <RePieChart>
                        <Pie
                          data={sexData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={70}
                          paddingAngle={3}
                        >
                          {sexData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                      </RePieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total</span>
                      <span className="text-lg font-black text-slate-800">{stats.totalPersonas || 0}</span>
                    </div>
                  </div>

                  {/* Gender legend */}
                  <div className="space-y-3 flex-1 w-full">
                    {sexData.map((d) => {
                      const pct = ((d.value / totalSexValues) * 100).toFixed(1);
                      return (
                        <div key={d.name} className="flex items-center justify-between text-xs py-2 border-b border-slate-100 last:border-b-0">
                          <div className="flex items-center gap-2">
                            <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: d.color }} />
                            <span className="font-semibold text-slate-700">{d.name}</span>
                          </div>
                          <span className="text-slate-600 font-bold">{d.value} <span className="text-slate-400 font-normal">({pct}%)</span></span>
                        </div>
                      );
                    })}
                  </div>

                </div>
              </div>

            </div>
          )}

          {/* TAB 3: LOGISTICA */}
          {activeTab === 'logistica' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* Shirt Sizes */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">Tallas de Ropa Requeridas (Camisas)</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Insumos necesarios de ropa para entrega de donaciones de vestir.</p>
                </div>

                <div className="bg-slate-50/50 rounded-xl p-4 border border-slate-100 space-y-2">
                  {logistics.topShirts.length === 0 ? (
                    <div className="text-slate-400 text-xs italic text-center py-4">Falta información de tallas</div>
                  ) : (
                    logistics.topShirts.map((item, idx) => (
                      <div key={item.size} className="flex items-center justify-between text-xs py-2 border-b border-slate-200/35 last:border-0">
                        <span className="font-bold text-slate-700 bg-sky-50 text-sky-800 px-2.5 py-1 rounded-md">Talla {item.size}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-24 h-2 bg-slate-200 rounded-full overflow-hidden hidden sm:block">
                            <div 
                              style={{ width: `${(item.count / logistics.topShirts[0].count) * 100}%` }}
                              className="h-full bg-slate-600 rounded-full"
                            />
                          </div>
                          <span className="text-slate-500 font-semibold">{item.count} personas</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Shoe Sizes */}
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm">Tallas de Calzado Requeridas</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Demanda de calzado agrupada por número de zapato nacional.</p>
                </div>

                <div className="bg-slate-50/50 rounded-xl p-4 border border-slate-100 space-y-2">
                  {logistics.topShoes.length === 0 ? (
                    <div className="text-slate-400 text-xs italic text-center py-4">Falta información de calzado</div>
                  ) : (
                    logistics.topShoes.map((item) => (
                      <div key={item.size} className="flex items-center justify-between text-xs py-2 border-b border-slate-200/35 last:border-0">
                        <span className="font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">Calzado {item.size}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-24 h-2 bg-slate-200 rounded-full overflow-hidden hidden sm:block">
                            <div 
                              style={{ width: `${(item.count / logistics.topShoes[0].count) * 100}%` }}
                              className="h-full bg-slate-500 rounded-full"
                            />
                          </div>
                          <span className="text-slate-500 font-semibold">{item.count} zap.</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
}
