/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Download, Upload, CheckCircle2, AlertCircle, HelpCircle, FileSpreadsheet } from 'lucide-react';
import { FichaSocial } from '../types';
import { downloadExcelTemplate, importFromExcel } from '../utils/excelHelper';

interface CargasMasivasProps {
  fichas: FichaSocial[];
  onImportFichas: (newFichas: FichaSocial[]) => void;
  stats: any;
}

export default function CargasMasivas({
  fichas,
  onImportFichas,
  stats
}: CargasMasivasProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 6000);
  };

  const handleDownloadTemplate = () => {
    try {
      downloadExcelTemplate();
      showMessage('success', 'Planilla oficial de caracterización social (.xlsx) descargada correctamente.');
    } catch (e) {
      showMessage('error', 'Error al generar la plantilla de descarga.');
    }
  };

  const handleImportExcel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    try {
      const imported = await importFromExcel(file);
      if (imported.length === 0) {
        showMessage('error', 'No se encontraron registros de caracterización válidos en el archivo Excel.');
      } else {
        onImportFichas(imported);
        showMessage('success', `Carga Masiva Exitosa: Se han importado ${imported.length} nuevas fichas familiares al censo.`);
      }
    } catch (err) {
      showMessage('error', (err as Error).message);
    } finally {
      setLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8" id="panel-cargas-masivas">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-800 uppercase tracking-tight">Cargas Masivas Automatizadas</h2>
          <p className="text-xs text-slate-500 mt-1">Intercambio veloz de datos utilizando el modelo de planilla oficial de la Ficha de Caracterización Social.</p>
        </div>
        <div className="mt-2 sm:mt-0 bg-slate-100 border border-slate-200 px-3 py-1 rounded-md text-[11px] font-bold text-slate-600 uppercase">
          Fichas en memoria: {fichas.length}
        </div>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 text-xs sm:text-sm ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="font-bold">{message.type === 'success' ? 'Operación Exitosa' : 'Error en Carga'}</p>
            <p className="mt-1 leading-relaxed text-slate-600 font-medium">{message.text}</p>
          </div>
        </div>
      )}

      {/* DETAILED CARDS SECTION AND INFO */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-8">
        
        {/* LEFT INFORMATION GUIDE CARD */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-slate-50/70 border border-slate-200/60 flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-3 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-blue-500" />
              Instrucciones y Estandarización de Fichas
            </h3>
            <ul className="space-y-2 text-xs text-slate-600">
              <li className="flex items-start gap-2">
                <span className="text-emerald-500 font-black">✔</span>
                <span><strong>Estructura Fija:</strong> Descargue el archivo de planilla oficial. No mueva las celdas para evitar errores de alineación en el motor de importación.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-500 font-black">✔</span>
                <span><strong>Listas Desplegables Integradas:</strong> Utilice las listas para completar de forma precisa campos regulados como <strong>Sexo</strong>, <strong>Grado de Instrucción</strong>, <strong>Paréntesis</strong> y <strong>Vulnerabilidades</strong>.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-500 font-black">✔</span>
                <span><strong>Grupo Familiar:</strong> Ingrese el detalle de familiares en las filas inferiores de la planilla (del 1 al 10). Se vincularán automáticamente al Jefe.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-500 font-black">✔</span>
                <span><strong>Compatibilidad:</strong> El sistema lee tanto el nuevo formato de Ficha Individual visual como la base estructurada multilineal clásica.</span>
              </li>
            </ul>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-200/60 flex items-center gap-3">
            <div className="w-10 h-10 rounded bg-blue-100 flex items-center justify-center text-blue-600 shrink-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[11px] font-bold text-slate-700 uppercase">Fórmula de Validación de Campos</p>
              <p className="text-[10px] text-slate-500 mt-0.5">El procesador verifica duplicados y calcula edades basadas en la fecha de nacimiento.</p>
            </div>
          </div>
        </div>

        {/* RIGHT VISUAL BUTTONS CARD AS IN THE SECOND IMAGE */}
        <div className="p-6 rounded-xl border border-slate-200 flex flex-col justify-center items-center bg-slate-50/20 shadow-xs">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 text-center">Panel de Acciones Masivas</p>
          
          <div className="flex flex-col gap-3.5 w-full max-w-xs">
            
            {/* BLUE BUTTON: Descargar Planilla (.xlsx) */}
            <button
              onClick={handleDownloadTemplate}
              className="w-full flex items-center justify-center gap-2.5 py-3 px-5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-wide rounded-lg shadow-sm border border-blue-700 transition-all cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
              id="btn-descargar-planilla"
              title="Descargar Planilla en formato Excel"
            >
              <Download className="w-4 h-4 text-white shrink-0" />
              <span>Descargar Planilla (.xlsx)</span>
            </button>

            {/* PURPLE BUTTON: Importar Excel (.xlsx) */}
            <label 
              className={`w-full flex items-center justify-center gap-2.5 py-3 px-5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wide rounded-lg shadow-sm border border-indigo-700 transition-all cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0 text-center ${
                loading ? 'opacity-70 cursor-not-allowed' : ''
              }`}
              id="btn-importar-excel"
              title="Importar archivo Excel completado"
            >
              <Upload className="w-4 h-4 text-white shrink-0" />
              <span>{loading ? 'Procesando...' : 'Importar Excel (.xlsx)'}</span>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls"
                onChange={handleImportExcel}
                className="hidden"
                disabled={loading}
              />
            </label>

          </div>

          <p className="text-[10px] text-slate-400 text-center mt-4 italic font-medium">
            Soporta formatos estándar de Excel (.xlsx, .xls)
          </p>
        </div>

      </div>

    </div>
  );
}
