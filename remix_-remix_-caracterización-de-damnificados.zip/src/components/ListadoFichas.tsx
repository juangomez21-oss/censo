/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Search, MapPin, Phone, Calendar, Heart, Shield, FileText, Wrench, Trash2, Eye, EyeOff, UserSquare } from 'lucide-react';
import { FichaSocial } from '../types';
import { exportFichaPDF } from '../utils/pdfHelper';
import { exportFichaWord } from '../utils/wordHelper';

interface ListadoFichasProps {
  fichas: FichaSocial[];
  onEditFicha: (ficha: FichaSocial) => void;
  onDeleteFicha: (id: string) => void;
}

export default function ListadoFichas({ fichas, onEditFicha, onDeleteFicha }: ListadoFichasProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterEstado, setFilterEstado] = useState('');
  const [filterDiscapacidad, setFilterDiscapacidad] = useState('');
  const [filterSalud, setFilterSalud] = useState('');
  
  // Expanded detailed card state
  const [selectedFicha, setSelectedFicha] = useState<FichaSocial | null>(null);

  // Filter unique states in current dataset for filtering dropdown
  const uniqueEstados = Array.from(new Set(fichas.map(f => f.estado).filter(Boolean)));

  // Filtered dataset
  const filteredFichas = fichas.filter(f => {
    const matchesSearch = 
      f.cedula.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.nombres.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.apellidos.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesEstado = filterEstado ? f.estado === filterEstado : true;
    const matchesDiscapacidad = filterDiscapacidad ? f.discapacidad === filterDiscapacidad : true;
    const matchesSalud = filterSalud ? (filterSalud === 'Sí' ? f.tipoEnfermedad !== 'Ninguna' : f.tipoEnfermedad === 'Ninguna') : true;

    return matchesSearch && matchesEstado && matchesDiscapacidad && matchesSalud;
  });

  return (
    <div className="space-y-6" id="listado-fichas-section">
      
      {/* SEARCH AND FILTERS PANEL */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-xs p-5">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Search bar */}
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="w-4 h-4" />
            </span>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por cédula, nombre o apellido..."
              className="w-full pl-9 pr-3.5 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500"
            />
          </div>

          {/* Estado filter */}
          <div>
            <select
              value={filterEstado}
              onChange={(e) => setFilterEstado(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-xs text-slate-700 focus:outline-none"
            >
              <option value="">-- Todos los Estados --</option>
              {uniqueEstados.map(est => (
                <option key={est} value={est}>{est}</option>
              ))}
            </select>
          </div>

          {/* Discapacidad filter */}
          <div>
            <select
              value={filterDiscapacidad}
              onChange={(e) => setFilterDiscapacidad(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-xs text-slate-700 focus:outline-none"
            >
              <option value="">-- Discapacidad (Todos) --</option>
              <option value="Sí">Con Discapacidad</option>
              <option value="No">Sin Discapacidad</option>
            </select>
          </div>

          {/* Enfermedad filter */}
          <div>
            <select
              value={filterSalud}
              onChange={(e) => setFilterSalud(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 bg-white rounded-lg text-xs text-slate-700 focus:outline-none"
            >
              <option value="">-- Condición Médica (Todos) --</option>
              <option value="Sí">Con Patología / Crónicos</option>
              <option value="No">Sin Patologías</option>
            </select>
          </div>

        </div>
      </div>

      {/* SEARCH DATA OUTCOME GRID */}
      {filteredFichas.length === 0 ? (
        <div className="bg-slate-50 border border-slate-100 border-dashed rounded-xl p-10 text-center">
          <p className="text-slate-400 italic text-xs">No se encontraron fichas que coincidan con los criterios de búsqueda.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredFichas.map(ficha => (
            <div 
              key={ficha.id} 
              className="bg-white rounded-xl border border-slate-100 shadow-2xs hover:shadow-xs transition-shadow p-5 flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-2 py-0.5 rounded-sm uppercase tracking-wide">
                      C.I: {ficha.cedula}
                    </span>
                    <h3 className="text-sm font-semibold text-slate-800 mt-1.5 uppercase">
                      {ficha.nombres} {ficha.apellidos}
                    </h3>
                  </div>
                  
                  <span className="bg-emerald-50 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                    {ficha.cantidadPersonas} Personas
                  </span>
                </div>

                {/* Grid attributes */}
                <div className="grid grid-cols-2 gap-3.5 mt-4 text-[11px] text-slate-500 border-t border-slate-50 pt-3">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{ficha.estado} - {ficha.parroquia}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{ficha.telefono}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{ficha.edad} años ({ficha.sexo})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{ficha.gradoInstruccion}</span>
                  </div>
                </div>

                {/* Risk Badges */}
                <div className="flex flex-wrap gap-1.5 mt-4">
                  {ficha.tipoEnfermedad !== 'Ninguna' && (
                    <span className="text-[9px] font-semibold bg-rose-50 text-rose-700 px-2 py-0.5 rounded-md flex items-center gap-1">
                      <Heart className="w-2.5 h-2.5" />
                      {ficha.tipoEnfermedad}
                    </span>
                  )}
                  {ficha.discapacidad === 'Sí' && (
                    <span className="text-[9px] font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md">
                      ♿ {ficha.tipoDiscapacidad}
                    </span>
                  )}
                  {ficha.alergico === 'Sí' && (
                    <span className="text-[9px] font-semibold bg-amber-50 text-amber-700 px-2 py-0.5 rounded-md">
                      ⚠️ Alérgico(a)
                    </span>
                  )}
                </div>
              </div>

              {/* CARD ACTIONS */}
              <div className="flex items-center justify-between border-t border-slate-50 mt-5 pt-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setSelectedFicha(ficha)}
                    className="flex items-center gap-1 text-[11px] font-bold text-sky-700 hover:text-sky-800 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" /> Ver Ficha
                  </button>
                  <button
                    onClick={() => exportFichaPDF(ficha)}
                    className="flex items-center gap-1 text-[11px] font-bold text-rose-700 hover:text-rose-800 cursor-pointer"
                    title="Descargar PDF Resumen"
                  >
                    <FileText className="w-3.5 h-3.5" /> Descargar PDF
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEditFicha(ficha)}
                    className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-50 rounded-md transition-colors cursor-pointer"
                    title="Editar Ficha"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`¿Está seguro de eliminar la ficha de ${ficha.nombres} ${ficha.apellidos}? Esta acción es irreversible.`)) {
                        onDeleteFicha(ficha.id);
                      }
                    }}
                    className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50/50 rounded-md transition-colors cursor-pointer"
                    title="Eliminar Ficha"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* --- FLOATING MODAL OVERLAY: RICH DETAILED VIEW --- */}
      {selectedFicha && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col shadow-xl overflow-hidden animate-in fade-in zoom-in duration-200">
            
            {/* Modal Header */}
            <div className="bg-sky-950 text-white p-5 flex items-center justify-between shrink-0">
              <div>
                <span className="text-[9px] bg-sky-800 text-sky-100 font-bold px-2 py-0.5 rounded-sm uppercase">
                  Censo Social - C.I: {selectedFicha.cedula}
                </span>
                <h3 className="text-sm font-bold uppercase mt-1">
                  {selectedFicha.nombres} {selectedFicha.apellidos}
                </h3>
              </div>
              <button 
                onClick={() => setSelectedFicha(null)}
                className="text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10"
              >
                <EyeOff className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-6">
              
              {/* Individual Export Buttons inside detailed view */}
              <div className="flex flex-wrap items-center gap-2.5 pb-4 border-b border-slate-100">
                <span className="text-xs font-semibold text-slate-500">Exportar Ficha Individual:</span>
                <button
                  onClick={() => exportFichaPDF(selectedFicha)}
                  className="flex items-center gap-1 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[10px] rounded-lg transition-colors"
                >
                  <FileText className="w-3 h-3" /> Descargar PDF
                </button>
                <button
                  onClick={() => exportFichaWord(selectedFicha)}
                  className="flex items-center gap-1 px-3 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-[10px] rounded-lg transition-colors"
                >
                  <FileText className="w-3 h-3" /> Descargar Word (.doc)
                </button>
              </div>

              {/* Grid 1: Jefe de Familia */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs text-sky-900 uppercase tracking-wide border-b border-slate-100 pb-1">1. Datos del Jefe(a) de Familia</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <p className="text-slate-400 font-medium">Fecha de Nacimiento</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.fechaNacimiento}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Edad Calculada</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.edad} años</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Género / Sexo</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.sexo}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Grado Instrucción</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.gradoInstruccion}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Profesión u Oficio</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.profesionOficio || 'Ninguno'}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Teléfono Principal</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.telefono}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Camisa / Pantalón</p>
                    <p className="font-semibold text-slate-700 mt-0.5">C: {selectedFicha.tallaCamisa} | P: {selectedFicha.tallaPantalon}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Número de Calzado</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.numeroCalzado}</p>
                  </div>
                </div>

                {/* Salud Detallada */}
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <p className="text-slate-500 font-semibold">Condición de Salud:</p>
                    <p className="text-slate-700 mt-0.5">
                      Enfermedad: <strong className="text-slate-900">{selectedFicha.tipoEnfermedad || 'Ninguna'}</strong>
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      ¿Tratamiento Médico Activo?: <strong className="text-slate-700">{selectedFicha.tratamientoMedicoActivo}</strong>
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-500 font-semibold">Vulnerabilidad Crítica:</p>
                    <p className="text-slate-700 mt-0.5">
                      Discapacidad: <strong className="text-slate-900">{selectedFicha.discapacidad === 'Sí' ? selectedFicha.tipoDiscapacidad : 'No'}</strong>
                    </p>
                    <p className="text-[10px] text-slate-500 mt-1">
                      Alergias Detectadas: <strong className="text-slate-700">{selectedFicha.alergico === 'Sí' ? selectedFicha.medicamentoAlergico : 'No'}</strong>
                    </p>
                  </div>
                </div>
              </div>

              {/* Grid 2: Equipo Responsable & Territorio */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs text-sky-900 uppercase tracking-wide border-b border-slate-100 pb-1">2. Ubicación y Registro Social</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <p className="text-slate-400 font-medium">Fecha de Ingreso</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.fechaIngreso}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Estado</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.estado}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Municipio / Parroquia</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.municipio} / {selectedFicha.parroquia}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-slate-400 font-medium">Dirección Procedencia Exacta</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.direccionProcedencia}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 font-medium">Evaluador / Brigadista</p>
                    <p className="font-semibold text-slate-700 mt-0.5">{selectedFicha.responsableFamilia} ({selectedFicha.telefonoResponsable})</p>
                  </div>
                </div>
              </div>

              {/* Grid 3: Grupo Familiar */}
              <div className="space-y-3">
                <h4 className="font-bold text-xs text-sky-900 uppercase tracking-wide border-b border-slate-100 pb-1">3. Integrantes Familiares</h4>
                
                {selectedFicha.grupoFamiliar.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No posee familiares secundarios registrados.</p>
                ) : (
                  <div className="border border-slate-100 rounded-lg overflow-hidden">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                          <th className="p-2 pl-3">Parentesco</th>
                          <th className="p-2">Nombre y Apellido</th>
                          <th className="p-2">Edad</th>
                          <th className="p-2">Tallas (Calz/Cam/Pant)</th>
                          <th className="p-2">Enfermedad</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedFicha.grupoFamiliar.map((f) => (
                          <tr key={f.id} className="text-slate-600">
                            <td className="p-2 pl-3 font-semibold text-slate-700">{f.parentezco}</td>
                            <td className="p-2">{f.nombresApellidos}</td>
                            <td className="p-2">{f.edad} años ({f.sexo})</td>
                            <td className="p-2 text-slate-500">Z:{f.numeroCalzado} | C:{f.tallaCamisa} | P:{f.tallaPantalon}</td>
                            <td className="p-2">{f.tipoEnfermedad}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Grid 4: Situación Actual */}
              <div className="space-y-2">
                <h4 className="font-bold text-xs text-sky-900 uppercase tracking-wide border-b border-slate-100 pb-1">4. Situación Social / Estatus Crítico</h4>
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700 leading-relaxed">
                  {selectedFicha.situacionActual || 'Sin observaciones cargadas.'}
                </div>
              </div>

              {/* Grid 5: Fotografías */}
              {selectedFicha.imagenes && selectedFicha.imagenes.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-sky-900 uppercase tracking-wide border-b border-slate-100 pb-1">5. Memoria Fotográfica</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {selectedFicha.imagenes.map((base64, index) => (
                      <div key={index} className="rounded-lg overflow-hidden border border-slate-200 shadow-2xs aspect-4/3">
                        <img src={base64} alt={`Censo Refugiado ${index + 1}`} className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-150 shrink-0 flex justify-end">
              <button
                onClick={() => setSelectedFicha(null)}
                className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
              >
                Cerrar
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
