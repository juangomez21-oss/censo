/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Familiar {
  id: string;
  parentezco: string;
  nombresApellidos: string;
  edad: number;
  sexo: 'Masculino' | 'Femenino' | 'Otro';
  tallaCamisa: string;
  tallaPantalon: string;
  numeroCalzado: string;
  tipoEnfermedad: string;
  alergica: 'Sí' | 'No';
}

export interface FichaSocial {
  id: string;
  
  // DATOS JEFE O JEFA DE FAMILIA
  cedula: string;
  nombres: string;
  apellidos: string;
  fechaNacimiento: string; // YYYY-MM-DD
  edad: number; // calculated
  telefono: string; // with +058 format
  sexo: 'Masculino' | 'Femenino' | 'Otro';
  gradoInstruccion: string;
  tallaCamisa: string;
  tallaPantalon: string;
  numeroCalzado: string;
  profesionOficio: string;
  tipoEnfermedad: string;
  tratamientoMedicoActivo: 'Sí' | 'No';
  discapacidad: 'Sí' | 'No';
  tipoDiscapacidad: string;
  alergico: 'Sí' | 'No';
  medicamentoAlergico: string;

  // EQUIPO RESPONSABLE DE FAMILIA
  fechaIngreso: string; // YYYY-MM-DD
  cantidadPersonas: number; // calculated
  direccionProcedencia: string;
  estado: string;
  municipio: string;
  parroquia: string;
  responsableFamilia: string;
  telefonoResponsable: string;

  // DATOS GRUPO FAMILIAR
  grupoFamiliar: Familiar[];

  // INFORMACIÓN GENERAL Y DETALLES
  situacionActual: string;

  // MEMORIA FOTOGRÁFICA
  imagenes: string[]; // array of base64 strings (optimized < 1MB)
  
  createdAt: string;
  updatedAt: string;
}

export interface DivisionPolitica {
  estados: {
    [estado: string]: {
      municipios: {
        [municipio: string]: string[]; // parroquias
      };
    };
  };
}
