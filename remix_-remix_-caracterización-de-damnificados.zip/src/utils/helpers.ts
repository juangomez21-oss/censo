/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Calculates age based on birth date and comparison date (usually fecha de ingreso).
 * @param birthDate string in format YYYY-MM-DD
 * @param comparisonDate string in format YYYY-MM-DD (defaults to current date if missing or invalid)
 */
export function calculateAge(birthDate: string, comparisonDate?: string): number {
  if (!birthDate) return 0;
  
  const birth = new Date(birthDate);
  if (isNaN(birth.getTime())) return 0;

  const refDate = comparisonDate ? new Date(comparisonDate) : new Date();
  const target = isNaN(refDate.getTime()) ? new Date() : refDate;

  let age = target.getFullYear() - birth.getFullYear();
  const monthDiff = target.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && target.getDate() < birth.getDate())) {
    age--;
  }
  
  return age < 0 ? 0 : age;
}

/**
 * Formats a phone number to Venezuelan standard with prefix +058.
 * Expects input like +0584123456789 or 4121234567 or 0412-1234567.
 * Standard format: +058 (XXX) XXX-XXXX or similar.
 */
export function formatVenezuelaPhone(phone: string): string {
  // Remove non-numeric characters except +
  let cleaned = phone.replace(/[^\d+]/g, '');

  // If it starts with +058 or +58 or 58 or 058, remove it to normalize
  if (cleaned.startsWith('+058')) {
    cleaned = cleaned.substring(4);
  } else if (cleaned.startsWith('+58')) {
    cleaned = cleaned.substring(3);
  } else if (cleaned.startsWith('058')) {
    cleaned = cleaned.substring(3);
  } else if (cleaned.startsWith('58')) {
    cleaned = cleaned.substring(2);
  }

  // Also remove leading 0 if present (e.g. 0412 -> 412)
  if (cleaned.startsWith('0')) {
    cleaned = cleaned.substring(1);
  }

  // If empty or too short, return as is (just prefix)
  if (!cleaned) {
    return '+058 ';
  }

  // Limit digits to 10 (Venezuelan mobile/fixed is 10 digits, e.g., 412 123 4567)
  const digits = cleaned.substring(0, 10);

  // Format: +058 (Code) XXX-XXXX
  if (digits.length <= 3) {
    return `+058 (${digits}`;
  } else if (digits.length <= 6) {
    return `+058 (${digits.substring(0, 3)}) ${digits.substring(3)}`;
  } else {
    return `+058 (${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6)}`;
  }
}

/**
 * Compresses an image file (jpg, png, webp) using HTML5 Canvas to keep it under 1MB.
 * Returns a Promise that resolves to a Base64 string.
 */
export function compressImage(file: File, maxDimension = 1024, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Resize if it exceeds max dimension
        if (width > height) {
          if (width > maxDimension) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          }
        } else {
          if (height > maxDimension) {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get Canvas 2D context'));
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        
        // Output as jpeg with controlled quality
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => {
        reject(new Error('Failed to load image into object'));
      };
      if (event.target?.result) {
        img.src = event.target.result as string;
      } else {
        reject(new Error('FileReader result is empty'));
      }
    };
    reader.onerror = () => {
      reject(new Error('FileReader failed'));
    };
    reader.readAsDataURL(file);
  });
}
