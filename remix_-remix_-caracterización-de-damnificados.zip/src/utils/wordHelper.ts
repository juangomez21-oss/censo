/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FichaSocial } from '../types';

/**
 * Exports a single social characterization card as a fully-styled Microsoft Word (.doc) document
 * by building an MS-Word-compatible HTML payload.
 */
export function exportFichaWord(ficha: FichaSocial) {
  const title = `Ficha_Social_Cedula_${ficha.cedula}`;
  
  const htmlContent = `
    <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
    <head>
      <title>Ficha Caracterización Social</title>
      <style>
        body { font-family: 'Arial', sans-serif; font-size: 11pt; color: #333333; line-height: 1.3; }
        .header-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .header-title { font-size: 16pt; font-weight: bold; color: #0d6e8b; text-align: center; padding-bottom: 5px; }
        .header-meta { font-size: 9pt; color: #666666; text-align: center; }
        .section-header { background-color: #0d6e8b; color: #ffffff; font-weight: bold; font-size: 11pt; padding: 6px 10px; margin-top: 20px; margin-bottom: 10px; text-transform: uppercase; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .data-table td { padding: 6px; border: 1px solid #dddddd; vertical-align: top; }
        .label { font-weight: bold; font-size: 9.5pt; color: #555555; text-transform: uppercase; }
        .value { font-size: 10pt; color: #111111; }
        .familiar-table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .familiar-table th { background-color: #f2f5f7; border: 1px solid #cccccc; padding: 6px; text-align: left; font-size: 9pt; font-weight: bold; }
        .familiar-table td { border: 1px solid #dddddd; padding: 6px; font-size: 9.5pt; }
        .observation-box { background-color: #f9fafb; border: 1px solid #dddddd; padding: 12px; font-size: 10pt; margin-top: 10px; min-height: 80px; }
        .signature-section { margin-top: 50px; width: 100%; }
        .signature-table { width: 100%; border-collapse: collapse; }
        .signature-line { border-top: 1px solid #888888; text-align: center; font-size: 9pt; font-weight: bold; padding-top: 5px; width: 45%; }
        .signature-space { width: 10%; }
      </style>
    </head>
    <body>
      <table class="header-table">
        <tr>
          <td class="header-title">FICHA CARACTERIZACIÓN SOCIAL DE DAMNIFICADOS</td>
        </tr>
        <tr>
          <td class="header-meta">ID FICHA: ${ficha.id} | FECHA REGISTRO: ${new Date(ficha.createdAt).toLocaleDateString()}</td>
        </tr>
      </table>

      <div class="section-header">Datos Jefe o Jefa de Familia</div>
      <table class="data-table">
        <tr>
          <td width="33%"><span class="label">Cédula:</span><br/><span class="value">${ficha.cedula}</span></td>
          <td width="33%"><span class="label">Nombres:</span><br/><span class="value">${ficha.nombres}</span></td>
          <td width="34%"><span class="label">Apellidos:</span><br/><span class="value">${ficha.apellidos}</span></td>
        </tr>
        <tr>
          <td><span class="label">Fecha Nacimiento:</span><br/><span class="value">${ficha.fechaNacimiento}</span></td>
          <td><span class="label">Edad Calculada:</span><br/><span class="value">${ficha.edad} años</span></td>
          <td><span class="label">Teléfono:</span><br/><span class="value">${ficha.telefono}</span></td>
        </tr>
        <tr>
          <td><span class="label">Sexo:</span><br/><span class="value">${ficha.sexo}</span></td>
          <td><span class="label">Grado Instrucción:</span><br/><span class="value">${ficha.gradoInstruccion}</span></td>
          <td><span class="label">Profesión / Oficio:</span><br/><span class="value">${ficha.profesionOficio}</span></td>
        </tr>
        <tr>
          <td><span class="label">Talla Camisa:</span><br/><span class="value">${ficha.tallaCamisa}</span></td>
          <td><span class="label">Talla Pantalón:</span><br/><span class="value">${ficha.tallaPantalon}</span></td>
          <td><span class="label">N° Calzado:</span><br/><span class="value">${ficha.numeroCalzado}</span></td>
        </tr>
        <tr>
          <td><span class="label">Tipo Enfermedad:</span><br/><span class="value">${ficha.tipoEnfermedad || 'Ninguna'}</span></td>
          <td><span class="label">Tratamiento Activo:</span><br/><span class="value">${ficha.tratamientoMedicoActivo}</span></td>
          <td><span class="label">Discapacidad:</span><br/><span class="value">${ficha.discapacidad} ${ficha.discapacidad === 'Sí' ? `(${ficha.tipoDiscapacidad})` : ''}</span></td>
        </tr>
        <tr>
          <td colspan="3"><span class="label">Alergias:</span> <span class="value">${ficha.alergico} ${ficha.alergico === 'Sí' ? `- Alérgico a: ${ficha.medicamentoAlergico}` : ''}</span></td>
        </tr>
      </table>

      <div class="section-header">Equipo Responsable de Familia</div>
      <table class="data-table">
        <tr>
          <td width="50%"><span class="label">Fecha Ingreso:</span><br/><span class="value">${ficha.fechaIngreso}</span></td>
          <td width="50%"><span class="label">Cantidad de Personas (Grupo Familiar):</span><br/><span class="value">${ficha.cantidadPersonas} (Jefe de Familia + ${ficha.grupoFamiliar.length} familiares)</span></td>
        </tr>
        <tr>
          <td><span class="label">Estado:</span><br/><span class="value">${ficha.estado}</span></td>
          <td><span class="label">Municipio:</span><br/><span class="value">${ficha.municipio}</span></td>
        </tr>
        <tr>
          <td><span class="label">Parroquia:</span><br/><span class="value">${ficha.parroquia}</span></td>
          <td><span class="label">Dirección Procedencia Exacta:</span><br/><span class="value">${ficha.direccionProcedencia}</span></td>
        </tr>
        <tr>
          <td><span class="label">Responsable Social Evaluador:</span><br/><span class="value">${ficha.responsableFamilia}</span></td>
          <td><span class="label">Teléfono Responsable:</span><br/><span class="value">${ficha.telefonoResponsable}</span></td>
        </tr>
      </table>

      <div class="section-header">Integrantes del Grupo Familiar</div>
      ${
        ficha.grupoFamiliar.length === 0 
        ? '<p style="font-style: italic; color: #777;">No se registraron integrantes familiares secundarios.</p>'
        : `
          <table class="familiar-table">
            <thead>
              <tr>
                <th>Parentezco</th>
                <th>Nombres y Apellidos</th>
                <th>Edad</th>
                <th>Sexo</th>
                <th>Calzado</th>
                <th>Camisa</th>
                <th>Pantalón</th>
                <th>Enfermedad</th>
                <th>Alergia</th>
              </tr>
            </thead>
            <tbody>
              ${ficha.grupoFamiliar.map(fam => `
                <tr>
                  <td>${fam.parentezco}</td>
                  <td>${fam.nombresApellidos}</td>
                  <td>${fam.edad} años</td>
                  <td>${fam.sexo}</td>
                  <td>${fam.numeroCalzado}</td>
                  <td>${fam.tallaCamisa}</td>
                  <td>${fam.tallaPantalon}</td>
                  <td>${fam.tipoEnfermedad}</td>
                  <td>${fam.alergica}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `
      }

      <div class="section-header">Situación Actual / Observaciones Colectivas</div>
      <div class="observation-box">
        ${ficha.situacionActual ? ficha.situacionActual.replace(/\n/g, '<br/>') : 'Sin observaciones detalladas.'}
      </div>

      <div class="signature-section">
        <br/><br/><br/>
        <table class="signature-table">
          <tr>
            <td class="signature-line">
              ________________________________________<br/>
              EQUIPO SOCIAL EVALUADOR
            </td>
            <td class="signature-space"></td>
            <td class="signature-line">
              ________________________________________<br/>
              AUTORIDAD RECEPTORA DE GESTIÓN
            </td>
          </tr>
        </table>
      </div>
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff' + htmlContent], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${title}.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
