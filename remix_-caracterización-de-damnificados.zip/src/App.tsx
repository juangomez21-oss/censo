/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import { useState, useEffect, useMemo } from 'react';
import { LayoutDashboard, UserPlus, ClipboardList, Database, ShieldAlert, Heart, Calendar, Menu, X, FileSpreadsheet, FileText, Settings } from 'lucide-react';
import { FichaSocial } from './types';
import Dashboard from './components/Dashboard';
import FormularioFicha from './components/FormularioFicha';
import ListadoFichas from './components/ListadoFichas';
import CargasMasivas from './components/CargasMasivas';
import Reporteador from './components/Reporteador';
import Mantenimiento from './components/Mantenimiento';

const LOCAL_STORAGE_KEY = 'censo_damnificados_db';

// --- HIGHLY REALISTIC SEED DATA FOR IMMEDIATE DASHBOARD VISIBILITY ---
const SEED_FICHAS: FichaSocial[] = [
  {
    id: 'ficha-seed-1',
    cedula: '14234567',
    nombres: 'José Gregorio',
    apellidos: 'Hernández Castillo',
    fechaNacimiento: '1981-10-24',
    edad: 44,
    telefono: '+058 (412) 765-4321',
    sexo: 'Masculino',
    gradoInstruccion: 'Bachiller',
    tallaCamisa: 'M',
    tallaPantalon: '32',
    numeroCalzado: '41',
    profesionOficio: 'Electricista',
    tipoEnfermedad: 'Hipertensión',
    tratamientoMedicoActivo: 'Sí',
    discapacidad: 'No',
    tipoDiscapacidad: 'Ninguna',
    alergico: 'No',
    medicamentoAlergico: '',
    fechaIngreso: '2026-06-15',
    cantidadPersonas: 4,
    direccionProcedencia: 'Calle Principal sector La Línea, Petare',
    estado: 'Miranda',
    municipio: 'Municipio Sucre',
    parroquia: 'Petare',
    responsableFamilia: 'Brigadista Ana Gómez',
    telefonoResponsable: '+058 (416) 111-2233',
    grupoFamiliar: [
      {
        id: 'fam-seed-1-1',
        parentezco: 'Esposo/a',
        nombresApellidos: 'Yuraima del Carmen Rondón',
        edad: 41,
        sexo: 'Femenino',
        tallaCamisa: 'M',
        tallaPantalon: '30',
        numeroCalzado: '37',
        tipoEnfermedad: 'Ninguna',
        alergica: 'No'
      },
      {
        id: 'fam-seed-1-2',
        parentezco: 'Hijo/a',
        nombresApellidos: 'Gregorio José Hernández',
        edad: 14,
        sexo: 'Masculino',
        tallaCamisa: 'S',
        tallaPantalon: '28',
        numeroCalzado: '39',
        tipoEnfermedad: 'Asma',
        alergica: 'Sí'
      },
      {
        id: 'fam-seed-1-3',
        parentezco: 'Hijo/a',
        nombresApellidos: 'Sofía Valentina Hernández',
        edad: 8,
        sexo: 'Femenino',
        tallaCamisa: 'XS',
        tallaPantalon: '10',
        numeroCalzado: '32',
        tipoEnfermedad: 'Ninguna',
        alergica: 'No'
      }
    ],
    situacionActual: 'Vivienda unifamiliar con colapso estructural completo de pared posterior y socavamiento de bases tras crecida de quebrada.',
    imagenes: [],
    createdAt: '2026-06-15T10:30:00Z',
    updatedAt: '2026-06-15T10:30:00Z'
  },
  {
    id: 'ficha-seed-2',
    cedula: '18556332',
    nombres: 'María Alejandra',
    apellidos: 'Briceño Marcano',
    fechaNacimiento: '1989-03-12',
    edad: 37,
    telefono: '+058 (414) 987-6543',
    sexo: 'Femenino',
    gradoInstruccion: 'Universitario Completo',
    tallaCamisa: 'S',
    tallaPantalon: '28',
    numeroCalzado: '36',
    profesionOficio: 'Enfermera',
    tipoEnfermedad: 'Ninguna',
    tratamientoMedicoActivo: 'No',
    discapacidad: 'No',
    tipoDiscapacidad: 'Ninguna',
    alergico: 'Sí',
    medicamentoAlergico: 'Dipirona y Penicilina',
    fechaIngreso: '2026-06-18',
    cantidadPersonas: 3,
    direccionProcedencia: 'Apartamento 3B, Edificio El Junko, Catia La Mar',
    estado: 'La Guaira',
    municipio: 'Municipio Vargas',
    parroquia: 'Catia La Mar',
    responsableFamilia: 'Coordinador Carlos Soto',
    telefonoResponsable: '+058 (424) 444-5566',
    grupoFamiliar: [
      {
        id: 'fam-seed-2-1',
        parentezco: 'Hijo/a',
        nombresApellidos: 'Santiago Briceño',
        edad: 6,
        sexo: 'Masculino',
        tallaCamisa: 'XS',
        tallaPantalon: '8',
        numeroCalzado: '29',
        tipoEnfermedad: 'Ninguna',
        alergica: 'No'
      },
      {
        id: 'fam-seed-2-2',
        parentezco: 'Madre',
        nombresApellidos: 'Isabel Teresa Marcano',
        edad: 67,
        sexo: 'Femenino',
        tallaCamisa: 'L',
        tallaPantalon: '34',
        numeroCalzado: '38',
        tipoEnfermedad: 'Hipertensión',
        alergica: 'No'
      }
    ],
    situacionActual: 'Pérdida de enseres por anegación total de planta baja debido a obstrucción de alcantarillado público durante lluvias continuas.',
    imagenes: [],
    createdAt: '2026-06-18T14:45:00Z',
    updatedAt: '2026-06-18T14:45:00Z'
  },
  {
    id: 'ficha-seed-3',
    cedula: '11880443',
    nombres: 'Eduardo José',
    apellidos: 'Vargas Silva',
    fechaNacimiento: '1968-07-05',
    edad: 57,
    telefono: '+058 (416) 333-8899',
    sexo: 'Masculino',
    gradoInstruccion: 'Primaria Completa',
    tallaCamisa: 'L',
    tallaPantalon: '36',
    numeroCalzado: '42',
    profesionOficio: 'Zapatero',
    tipoEnfermedad: 'Diabetes Mellitus Tipo II',
    tratamientoMedicoActivo: 'Sí',
    discapacidad: 'Sí',
    tipoDiscapacidad: 'Motora (Amputación de miembro inferior izquierdo)',
    alergico: 'No',
    medicamentoAlergico: '',
    fechaIngreso: '2026-06-20',
    cantidadPersonas: 1,
    direccionProcedencia: 'Sector El Recreo, San Bernardino',
    estado: 'Distrito Capital',
    municipio: 'Municipio Bolivariano Libertador',
    parroquia: 'San Bernardino',
    responsableFamilia: 'Brigadista Ana Gómez',
    telefonoResponsable: '+058 (416) 111-2233',
    grupoFamiliar: [],
    situacionActual: 'Paciente con movilidad reducida habitando en zona declarada de alto riesgo geológico. Reubicado preventivamente por agrietamiento de losa.',
    imagenes: [],
    createdAt: '2026-06-20T09:15:00Z',
    updatedAt: '2026-06-20T09:15:00Z'
  }
];

export default function App() {
  const [fichas, setFichas] = useState<FichaSocial[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'registro' | 'listado' | 'cargas' | 'reportes' | 'mantenimiento'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Edit Ficha state
  const [fichaParaEditar, setFichaParaEditar] = useState<FichaSocial | null>(null);

  // --- COMPONENT DID MOUNT: LOAD DATABASE ---
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        setFichas(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading fichas from storage", e);
        setFichas(SEED_FICHAS);
      }
    } else {
      // Seed default values for gorgeous dashboard visualization immediately
      setFichas(SEED_FICHAS);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(SEED_FICHAS));
    }
  }, []);

  // --- PERSIST CHANGES ---
  const saveToLocalStorage = (newList: FichaSocial[]) => {
    setFichas(newList);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newList));
  };

  // --- ACTION HANDLERS ---
  const handleSaveFicha = (ficha: FichaSocial) => {
    const exists = fichas.some(f => f.id === ficha.id);
    let updated: FichaSocial[];
    if (exists) {
      updated = fichas.map(f => f.id === ficha.id ? { ...ficha, updatedAt: new Date().toISOString() } : f);
    } else {
      updated = [ficha, ...fichas];
    }
    saveToLocalStorage(updated);
    setFichaParaEditar(null);
    setActiveTab('listado');
  };

  const handleEditRequest = (ficha: FichaSocial) => {
    setFichaParaEditar(ficha);
    setActiveTab('registro');
  };

  const handleDeleteFicha = (id: string) => {
    const updated = fichas.filter(f => f.id !== id);
    saveToLocalStorage(updated);
  };

  const handleImportMassive = (newFichas: FichaSocial[]) => {
    const updated = [...newFichas, ...fichas];
    saveToLocalStorage(updated);
  };

  const handleRestoreBackup = (allFichas: FichaSocial[]) => {
    saveToLocalStorage(allFichas);
  };

  // --- DYNAMIC LIVE METRICS & STATISTICS COMPILER ---
  const stats = useMemo(() => {
    let totalPersonas = 0;
    let conEnfermedad = 0;
    let conDiscapacidad = 0;
    let conAlergias = 0;
    let totalEdadJefes = 0;

    const distribucionEstados: Record<string, number> = {};
    const distribucionSexo: Record<string, number> = { Femenino: 0, Masculino: 0, Otro: 0 };
    
    // Age ranges for census
    const rangosEdad = {
      ninos: 0, // 0-11
      jovenes: 0, // 12-17
      adultos: 0, // 18-59
      ancianos: 0 // 60+
    };

    fichas.forEach(f => {
      // 1. Total protected counts
      totalPersonas += 1; // Jefe
      totalPersonas += f.grupoFamiliar.length; // family members

      // 2. Health & Vulnerabilities
      if (f.tipoEnfermedad && f.tipoEnfermedad !== 'Ninguna') conEnfermedad++;
      if (f.discapacidad === 'Sí') conDiscapacidad++;
      if (f.alergico === 'Sí') conAlergias++;

      // Family health indicators
      f.grupoFamiliar.forEach(fam => {
        if (fam.tipoEnfermedad && fam.tipoEnfermedad !== 'Ninguna') conEnfermedad++;
        if (fam.alergica === 'Sí') conAlergias++;
      });

      // 3. Demographics
      totalEdadJefes += f.edad;

      // Classify Jefe Age
      if (f.edad <= 11) rangosEdad.ninos++;
      else if (f.edad <= 17) rangosEdad.jovenes++;
      else if (f.edad <= 59) rangosEdad.adultos++;
      else rangosEdad.ancianos++;

      // Classify Family Ages
      f.grupoFamiliar.forEach(fam => {
        if (fam.edad <= 11) rangosEdad.ninos++;
        else if (fam.edad <= 17) rangosEdad.jovenes++;
        else if (fam.edad <= 59) rangosEdad.adultos++;
        else rangosEdad.ancianos++;
      });

      // Genders
      distribucionSexo[f.sexo] = (distribucionSexo[f.sexo] || 0) + 1;
      f.grupoFamiliar.forEach(fam => {
        distribucionSexo[fam.sexo] = (distribucionSexo[fam.sexo] || 0) + 1;
      });

      // Territorial distribution (by States)
      if (f.estado) {
        distribucionEstados[f.estado] = (distribucionEstados[f.estado] || 0) + 1;
      }
    });

    const edadPromedio = fichas.length > 0 ? Math.round(totalEdadJefes / fichas.length) : 0;

    return {
      totalPersonas,
      conEnfermedad,
      conDiscapacidad,
      conAlergias,
      edadPromedio,
      distribucionEstados,
      distribucionSexo,
      rangosEdad
    };
  }, [fichas]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans selection:bg-blue-600 selection:text-white" id="main-applet-layout">
      
      {/* MOBILE HEADER BAR */}
      <div className="md:hidden bg-slate-900 border-b border-slate-800 text-slate-300 px-4 py-3 flex items-center justify-between z-50 shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="w-7 h-7 bg-blue-600 rounded flex items-center justify-center font-bold text-white text-xs">CS</div>
          <span className="text-sm font-bold text-white tracking-tight uppercase">SISTEMA DAMNIFICADOS</span>
        </div>
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-1.5 hover:bg-slate-800 rounded-md text-slate-300 focus:outline-none"
          title="Toggle Navigation"
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* LEFT NAV SIDEBAR */}
      <aside className={`
        fixed inset-y-0 left-0 w-64 bg-slate-900 text-slate-300 flex flex-col border-r border-slate-800 z-40 transition-transform duration-300 transform 
        md:translate-x-0 md:static md:h-screen shrink-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Sidebar Header */}
        <div className="p-6 border-b border-slate-800 flex items-center space-x-3 shrink-0">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold text-white shadow-md">CS</div>
          <span className="text-base font-bold text-white tracking-tight leading-tight uppercase">SISTEMA DAMNIFICADOS</span>
        </div>

        {/* Navigation Options */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('dashboard');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'dashboard'
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 shrink-0 text-blue-500" />
            <span>Panel de Indicadores</span>
          </button>

          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('registro');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'registro' && !fichaParaEditar
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4 shrink-0 text-blue-500" />
            <span>Registro de Censo Social</span>
          </button>

          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('listado');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'listado'
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <ClipboardList className="w-4 h-4 shrink-0 text-blue-500" />
            <span>Gestión del Censo ({fichas.length})</span>
          </button>

          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('cargas');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'cargas'
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 shrink-0 text-emerald-500" />
            <span>Cargas Masivas</span>
          </button>

          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('reportes');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'reportes'
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4 shrink-0 text-sky-500" />
            <span>Generador de Reportes</span>
          </button>

          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('mantenimiento');
              setIsSidebarOpen(false);
            }}
            className={`w-full flex items-center space-x-3 p-3 transition-all rounded-lg text-xs font-bold uppercase tracking-wide border text-left ${
              activeTab === 'mantenimiento'
                ? 'bg-blue-600/20 text-blue-400 border-blue-600/30'
                : 'border-transparent text-slate-400 hover:bg-slate-800/80 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4 shrink-0 text-indigo-500" />
            <span>Mantenimiento</span>
          </button>
        </nav>

        {/* Sidebar Bottom Action */}
        <div className="p-4 border-t border-slate-800 space-y-2 shrink-0">
          <button
            onClick={() => {
              setFichaParaEditar(null);
              setActiveTab('mantenimiento');
              setIsSidebarOpen(false);
            }}
            className="w-full flex items-center justify-center space-x-2 bg-slate-800 hover:bg-slate-750 p-2.5 rounded text-xs font-bold text-white transition-colors border border-slate-700/50 cursor-pointer"
          >
            <Database className="w-3.5 h-3.5 text-blue-400" />
            <span>RESPALDO BASE DE DATOS</span>
          </button>
          <div className="text-[10px] text-center opacity-40 uppercase tracking-widest font-semibold">
            V 2.5.0 • COPIA LOCAL: {fichas.length > 0 ? 'ACTIVA' : 'VACÍA'}
          </div>
        </div>
      </aside>

      {/* MOBILE SIDEBAR BACKGROUND OVERLAY */}
      {isSidebarOpen && (
        <div 
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs z-30 md:hidden"
        />
      )}

      {/* RIGHT SIDE VIEW CONTAINER */}
      <main className="flex-1 flex flex-col min-w-0 md:h-screen md:overflow-hidden bg-slate-50">
        
        {/* ADMINISTRATIVE HEADER BAR */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sm:px-8 shrink-0 shadow-2xs z-10">
          <h2 className="text-sm sm:text-base md:text-lg font-bold text-slate-800 uppercase tracking-tight">
            {activeTab === 'dashboard' && 'Panel de Indicadores y Gestión'}
            {activeTab === 'registro' && (fichaParaEditar ? 'Editar Ficha de Caracterización' : 'Registro de Caracterización')}
            {activeTab === 'listado' && 'Listado y Expedientes del Censo'}
            {activeTab === 'cargas' && 'Cargas Masivas Automatizadas'}
            {activeTab === 'reportes' && 'Módulo Generador de Reportes'}
            {activeTab === 'mantenimiento' && 'Mantenimiento del Sistema'}
          </h2>

          <div className="flex items-center space-x-4">
            {/* Quick Actions (only on medium/large screens) */}
            <div className="hidden lg:flex space-x-2 shrink-0">
              <button 
                onClick={() => setActiveTab('cargas')}
                className="px-3 py-1.5 border border-emerald-600 text-emerald-600 rounded-md text-[11px] font-bold hover:bg-emerald-50 transition-colors uppercase cursor-pointer"
              >
                Excel Plantilla
              </button>
              <button 
                onClick={() => setActiveTab('cargas')}
                className="px-3 py-1.5 bg-emerald-600 text-white rounded-md text-[11px] font-bold hover:bg-emerald-700 transition-colors shadow-2xs shadow-emerald-200 uppercase cursor-pointer"
              >
                Importar Datos
              </button>
            </div>
          </div>
        </header>

        {/* WORKSPACE AREA CONTAINER */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          
          {/* Active section rendering */}
          {activeTab === 'dashboard' && (
            <Dashboard fichas={fichas} stats={stats} />
          )}

          {activeTab === 'registro' && (
            <FormularioFicha
              editFicha={fichaParaEditar}
              onSave={handleSaveFicha}
              onCancel={() => {
                setFichaParaEditar(null);
                setActiveTab('dashboard');
              }}
            />
          )}

          {activeTab === 'listado' && (
            <ListadoFichas
              fichas={fichas}
              onEditFicha={handleEditRequest}
              onDeleteFicha={handleDeleteFicha}
            />
          )}

          {activeTab === 'cargas' && (
            <CargasMasivas
              fichas={fichas}
              onImportFichas={handleImportMassive}
              stats={stats}
            />
          )}

          {activeTab === 'reportes' && (
            <Reporteador
              fichas={fichas}
              stats={stats}
            />
          )}

          {activeTab === 'mantenimiento' && (
            <Mantenimiento
              fichas={fichas}
              onRestoreBackup={handleRestoreBackup}
            />
          )}

        </div>

        {/* SYNCHRONIZATION BOTTOM METRICS RAIL */}
        <div className="bg-slate-900 px-5 py-3.5 flex flex-col sm:flex-row items-center justify-between text-white border-t border-slate-800 gap-3 shrink-0">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-6 text-center sm:text-left">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
              <span className="text-[10px] font-bold tracking-widest uppercase text-slate-200">Sincronización Regional Activa</span>
            </div>
            <div className="text-[11px] font-medium text-slate-400 truncate max-w-md">
              {fichas.length > 0 ? (
                <span>Último registro cargado: <strong className="text-slate-200 uppercase font-bold">{fichas[0].nombres} {fichas[0].apellidos}</strong> ({fichas[0].estado})</span>
              ) : (
                <span>Esperando datos de registro social...</span>
              )}
            </div>
          </div>
          <div className="flex space-x-4 text-[10px] text-slate-500 tracking-wider font-semibold shrink-0">
            <span>SALA SITUACIONAL VENEZUELA</span>
            <span>TÉRMINOS Y PRIVACIDAD</span>
          </div>
        </div>

      </main>

    </div>
  );
}
