/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as XLSX from 'xlsx';
import { FichaSocial, Familiar } from '../types';
import { calculateAge, formatVenezuelaPhone } from './helpers';

// Helpers to read and write cells cleanly
function addCell(ws: any, row: number, col: number, value: any, type: string = 's') {
  const cellRef = XLSX.utils.encode_cell({ r: row, c: col });
  ws[cellRef] = { v: value, t: type };
}

function getCellValue(ws: any, row: number, col: number): string {
  const cellRef = XLSX.utils.encode_cell({ r: row, c: col });
  const cell = ws[cellRef];
  if (!cell) return '';
  if (cell.v instanceof Date) {
    return cell.v.toISOString().split('T')[0];
  }
  return String(cell.v !== undefined ? cell.v : '').trim();
}

/**
 * Downloads a structured Excel template shaped exactly like the visual form in the image,
 * containing dropdown lists (data validations) for streamlined input.
 */
export function downloadExcelTemplate() {
  const wb = XLSX.utils.book_new();
  const ws: XLSX.WorkSheet = {
    '!ref': 'A1:I35'
  };

  // 1. Appending Merges for headers
  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 8 } }, // FICHA CARACTERIZACION SOCIAL
    { s: { r: 1, c: 0 }, e: { r: 1, c: 8 } }, // DATOS JEFE O JEFA DE FAMILIA
    { s: { r: 6, c: 0 }, e: { r: 6, c: 8 } }, // EQUIPO RESPONSABLE DE FAMILIA
    { s: { r: 9, c: 0 }, e: { r: 9, c: 8 } }, // DATOS GRUPO FAMILIAR
    { s: { r: 24, c: 0 }, e: { r: 24, c: 8 } }, // INFORMACIÓN GENERAL Y DETALLES
    { s: { r: 27, c: 0 }, e: { r: 27, c: 8 } }, // MEMORIA FOTOGRÁFICA
    { s: { r: 28, c: 0 }, e: { r: 28, c: 8 } }  // MEMORIA FOTOGRÁFICA TEXT
  ];

  // 2. Setting values for the structured layout
  addCell(ws, 0, 0, 'FICHA CARACTERIZACION SOCIAL');
  addCell(ws, 1, 0, 'DATOS JEFE O JEFA DE FAMILIA');

  // Row 3 (Index 2): Headers Jefe 1
  addCell(ws, 2, 0, 'CEDULA');
  addCell(ws, 2, 1, 'NOMBRES');
  addCell(ws, 2, 2, 'APELLIDOS');
  addCell(ws, 2, 3, 'FECHA DE NACIMIENTO (AAAA-MM-DD)');
  addCell(ws, 2, 4, 'EDAD');
  addCell(ws, 2, 5, 'TELEFONO');
  addCell(ws, 2, 6, 'SEXO');
  addCell(ws, 2, 7, 'GRADO DE INSTRUCCION');
  addCell(ws, 2, 8, 'TALLA CAMISA');

  // Row 4 (Index 3): Sample values Jefe 1
  addCell(ws, 3, 0, '12345678');
  addCell(ws, 3, 1, 'Juan Antonio');
  addCell(ws, 3, 2, 'Pérez García');
  addCell(ws, 3, 3, '1985-05-15');
  addCell(ws, 3, 4, '41', 'n');
  addCell(ws, 3, 5, '4121234567');
  addCell(ws, 3, 6, 'Masculino');
  addCell(ws, 3, 7, 'Universitario Completo');
  addCell(ws, 3, 8, 'M');

  // Row 5 (Index 4): Headers Jefe 2
  addCell(ws, 4, 0, 'TALLA PANTALON');
  addCell(ws, 4, 1, 'NUMERO CALZADO');
  addCell(ws, 4, 2, 'PROFECION / OFICIO');
  addCell(ws, 4, 3, 'TIPO ENFERMEDAD');
  addCell(ws, 4, 4, 'TRATAMIENTO MEDICO (ACTIVO)');
  addCell(ws, 4, 5, 'DISCAPACIDAD');
  addCell(ws, 4, 6, 'TIPO DE DISCAPACIDAD');
  addCell(ws, 4, 7, 'ALERGICO');
  addCell(ws, 4, 8, 'MEDICAMENTO (ALERGICO)');

  // Row 6 (Index 5): Sample values Jefe 2
  addCell(ws, 5, 0, '32');
  addCell(ws, 5, 1, '41');
  addCell(ws, 5, 2, 'Carpintero');
  addCell(ws, 5, 3, 'Hipertensión');
  addCell(ws, 5, 4, 'Sí');
  addCell(ws, 5, 5, 'No');
  addCell(ws, 5, 6, 'Ninguna');
  addCell(ws, 5, 7, 'No');
  addCell(ws, 5, 8, '');

  addCell(ws, 6, 0, 'EQUIPO RESPONSABLE DE FAMILIA');

  // Row 8 (Index 7): Headers Equipo
  addCell(ws, 7, 0, 'FECHA INGRESO (AAAA-MM-DD)');
  addCell(ws, 7, 1, 'CANTIDAD DE PERSONAS (FAMILIA)');
  addCell(ws, 7, 2, 'DIRECCION EXACTA PROCEDENCIA');
  addCell(ws, 7, 3, 'ESTADO');
  addCell(ws, 7, 4, 'MUNICIPIO');
  addCell(ws, 7, 5, 'PARROQUIA');
  addCell(ws, 7, 6, 'RESPONSABLE FAMILIA (EQUIPO)');
  addCell(ws, 7, 7, 'TELEFONO RESPONSABLE');

  // Row 9 (Index 8): Sample values Equipo
  addCell(ws, 8, 0, '2026-06-01');
  addCell(ws, 8, 1, '3', 'n');
  addCell(ws, 8, 2, 'Av. Libertador, Sector Chacao');
  addCell(ws, 8, 3, 'Miranda');
  addCell(ws, 8, 4, 'Municipio Chacao');
  addCell(ws, 8, 5, 'Chacao');
  addCell(ws, 8, 6, 'Carlos Gómez');
  addCell(ws, 8, 7, '4147654321');

  addCell(ws, 9, 0, 'DATOS GRUPO FAMILIAR');

  // Row 11 (Index 10): Headers Familiar
  addCell(ws, 10, 0, 'PARENTEZCO');
  addCell(ws, 10, 1, 'EDAD');
  addCell(ws, 10, 2, 'NOMBRES Y APELLIDOS');
  addCell(ws, 10, 3, 'SEXO');
  addCell(ws, 10, 4, 'TALLA CAMISA');
  addCell(ws, 10, 5, 'TALLA PANTALON');
  addCell(ws, 10, 6, 'NUMERO CALZADO');
  addCell(ws, 10, 7, 'TIPO ENFERMEDAD');
  addCell(ws, 10, 8, 'ALERGICA(O)');

  // Rows 12-21 (Index 11-20): Sample Group members
  addCell(ws, 11, 0, 'Hijo/a');
  addCell(ws, 11, 1, '12', 'n');
  addCell(ws, 11, 2, 'María Pérez');
  addCell(ws, 11, 3, 'Femenino');
  addCell(ws, 11, 4, 'S');
  addCell(ws, 11, 5, '14');
  addCell(ws, 11, 6, '36');
  addCell(ws, 11, 7, 'Ninguna');
  addCell(ws, 11, 8, 'No');

  addCell(ws, 12, 0, 'Esposo/a');
  addCell(ws, 12, 1, '38', 'n');
  addCell(ws, 12, 2, 'Ana de Pérez');
  addCell(ws, 12, 3, 'Femenino');
  addCell(ws, 12, 4, 'M');
  addCell(ws, 12, 5, '30');
  addCell(ws, 12, 6, '37');
  addCell(ws, 12, 7, 'Asma');
  addCell(ws, 12, 8, 'Sí');

  // Empty placeholder family rows to fill
  for (let r = 13; r <= 22; r++) {
    addCell(ws, r, 0, '');
    addCell(ws, r, 1, '');
    addCell(ws, r, 2, '');
    addCell(ws, r, 3, '');
    addCell(ws, r, 4, '');
    addCell(ws, r, 5, '');
    addCell(ws, r, 6, '');
    addCell(ws, r, 7, '');
    addCell(ws, r, 8, '');
  }

  addCell(ws, 23, 0, 'INFORMACIÓN GENERAL Y DETALLES');
  addCell(ws, 24, 0, 'SITUACIÓN ACTUAL');
  addCell(ws, 25, 0, 'Pérdida parcial de vivienda por deslizamiento de tierra en el Sector Chacao.');

  addCell(ws, 27, 0, 'MEMORIA FOTOGRÁFICA');
  addCell(ws, 28, 0, 'Permitir subir imágenes jpg, png, webp. El sistema optimiza la imagen para bajar peso (hasta un máximo de 1mb).');

  // 3. ENABLING EXCEL DROPDOWN LISTS (DATA VALIDATIONS)
  ws['!dataValidation'] = [
    // Sexo Jefe (Row 4 Col G -> index G4)
    { sqref: 'G4', type: 'list', formula1: '"Masculino,Femenino,Otro"' },
    // Grado Instrucción Jefe (Row 4 Col H -> index H4)
    { sqref: 'H4', type: 'list', formula1: '"Sin Instrucción,Primaria Incompleta,Primaria Completa,Secundaria Incompleta,Secundaria Completa,Técnico Medio,Técnico Superior,Universitario Incompleto,Universitario Completo,Postgrado"' },
    // Talla Camisa Jefe (Row 4 Col I -> index I4)
    { sqref: 'I4', type: 'list', formula1: '"S,M,L,XL,XXL,3XL,Niño 4,Niño 6,Niño 8,Niño 10,Niño 12,Niño 14,Niño 16"' },
    // Tratamiento Médico Activo Jefe (Row 6 Col E -> index E6)
    { sqref: 'E6', type: 'list', formula1: '"Sí,No"' },
    // Discapacidad Jefe (Row 6 Col F -> index F6)
    { sqref: 'F6', type: 'list', formula1: '"Sí,No"' },
    // Alérgico Jefe (Row 6 Col H -> index H6)
    { sqref: 'H6', type: 'list', formula1: '"Sí,No"' },
    
    // Family Group Dropdowns: Sexo (D12:D23)
    { sqref: 'D12:D23', type: 'list', formula1: '"Masculino,Femenino,Otro"' },
    // Family Group Dropdowns: Parentezco (A12:A23)
    { sqref: 'A12:A23', type: 'list', formula1: '"Hijo/a,Esposo/a,Padre/Madre,Hermano/a,Abuelo/a,Nieto/a,Tío/a,Sobrino/a,Primo/a,Otro"' },
    // Family Group Dropdowns: Talla Camisa (E12:E23)
    { sqref: 'E12:E23', type: 'list', formula1: '"S,M,L,XL,XXL,3XL,Niño 4,Niño 6,Niño 8,Niño 10,Niño 12,Niño 14,Niño 16"' },
    // Family Group Dropdowns: Alérgica (I12:I23)
    { sqref: 'I12:I23', type: 'list', formula1: '"Sí,No"' }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Ficha Individual');
  XLSX.writeFile(wb, 'Ficha_Caracterizacion_Social_Vacia.xlsx');
}

/**
 * Exports registered social cards into a well-formatted Excel workbook.
 */
export function exportToExcel(fichas: FichaSocial[]) {
  const wb = XLSX.utils.book_new();

  const jefesData = fichas.map(ficha => ({
    'Cedula Jefe': ficha.cedula,
    'Nombres Jefe': ficha.nombres,
    'Apellidos Jefe': ficha.apellidos,
    'Fecha Nacimiento (AAAA-MM-DD)': ficha.fechaNacimiento,
    'Edad': ficha.edad,
    'Telefono': ficha.telefono,
    'Sexo (Masculino/Femenino/Otro)': ficha.sexo,
    'Grado Instruccion': ficha.gradoInstruccion,
    'Talla Camisa': ficha.tallaCamisa,
    'Talla Pantalon': ficha.tallaPantalon,
    'Numero Calzado': ficha.numeroCalzado,
    'Profesion/Oficio': ficha.profesionOficio,
    'Tipo Enfermedad': ficha.tipoEnfermedad,
    'Tratamiento Medico Activo (Si/No)': ficha.tratamientoMedicoActivo,
    'Discapacidad (Si/No)': ficha.discapacidad,
    'Tipo Discapacidad': ficha.tipoDiscapacidad,
    'Alergico (Si/No)': ficha.alergico,
    'Medicamento Alergico': ficha.medicamentoAlergico,
    'Fecha Ingreso (AAAA-MM-DD)': ficha.fechaIngreso,
    'Cantidad Personas': ficha.cantidadPersonas,
    'Direccion Procedencia': ficha.direccionProcedencia,
    'Estado': ficha.estado,
    'Municipio': ficha.municipio,
    'Parroquia': ficha.parroquia,
    'Responsable Familia': ficha.responsableFamilia,
    'Telefono Responsable': ficha.telefonoResponsable,
    'Situacion Actual': ficha.situacionActual,
    'Fecha Registro': new Date(ficha.createdAt).toLocaleString()
  }));

  const familiaresData: any[] = [];
  fichas.forEach(ficha => {
    ficha.grupoFamiliar.forEach(fam => {
      familiaresData.push({
        'Cedula Jefe': ficha.cedula,
        'Nombres y Apellidos Familiar': fam.nombresApellidos,
        'Parentezco': fam.parentezco,
        'Edad Familiar': fam.edad,
        'Sexo Familiar (Masculino/Femenino/Otro)': fam.sexo,
        'Talla Camisa': fam.tallaCamisa,
        'Talla Pantalon': fam.tallaPantalon,
        'Numero Calzado': fam.numeroCalzado,
        'Tipo Enfermedad': fam.tipoEnfermedad,
        'Alergico (Si/No)': fam.alergica
      });
    });
  });

  const wsJefe = XLSX.utils.json_to_sheet(jefesData);
  const wsFamiliar = XLSX.utils.json_to_sheet(familiaresData);

  XLSX.utils.book_append_sheet(wb, wsJefe, 'Jefes de Familia');
  XLSX.utils.book_append_sheet(wb, wsFamiliar, 'Grupo Familiar');

  XLSX.writeFile(wb, 'Reporte_Caracterizacion_Social_Damnificados.xlsx');
}

/**
 * Imports records from an uploaded Excel file.
 * Handles both the graphical single-card "Ficha Individual" layout and the traditional tabular tables.
 */
export function importFromExcel(file: File): Promise<FichaSocial[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        if (!data) {
          reject(new Error('No se pudieron leer los datos del archivo.'));
          return;
        }

        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        const firstSheetName = workbook.SheetNames[0];
        const ws = workbook.Sheets[firstSheetName];

        const a1Val = String(ws['A1']?.v || '').trim();

        const fichas: FichaSocial[] = [];

        // MODE A: VISUAL INDIVIDUAL FICHA FORM (Matches image structure)
        if (a1Val.includes('FICHA CARACTERIZACION SOCIAL') || a1Val.includes('FICHA CARACTERIZACIÓN')) {
          const id = `ficha-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

          // Read Jefe Info (Row index 3 for Row 4)
          const cedulaVal = getCellValue(ws, 3, 0);
          if (!cedulaVal) {
            reject(new Error('La Cédula del Jefe de Familia está vacía en la celda A4.'));
            return;
          }

          const nombresVal = getCellValue(ws, 3, 1);
          const apellidosVal = getCellValue(ws, 3, 2);
          const birthVal = getCellValue(ws, 3, 3);
          const ageVal = Number(getCellValue(ws, 3, 4)) || calculateAge(birthVal, new Date().toISOString());
          const telVal = formatVenezuelaPhone(getCellValue(ws, 3, 5));
          
          let sexVal: 'Masculino' | 'Femenino' | 'Otro' = 'Masculino';
          const rSex = getCellValue(ws, 3, 6).toLowerCase();
          if (rSex.includes('fem') || rSex.startsWith('f')) sexVal = 'Femenino';
          else if (rSex.includes('otr') || rSex.startsWith('o')) sexVal = 'Otro';

          const gradoInst = getCellValue(ws, 3, 7);
          const tallaCamisaVal = getCellValue(ws, 3, 8);

          // Row 6 (Index 5) values
          const tallaPantalonVal = getCellValue(ws, 5, 0);
          const numCalzadoVal = getCellValue(ws, 5, 1);
          const profOficioVal = getCellValue(ws, 5, 2);
          const tipoEnfermedadVal = getCellValue(ws, 5, 3);
          const tratActivoVal = getCellValue(ws, 5, 4) === 'Sí' || getCellValue(ws, 5, 4).toLowerCase() === 'si' ? 'Sí' : 'No';
          const discapacidadVal = getCellValue(ws, 5, 5) === 'Sí' || getCellValue(ws, 5, 5).toLowerCase() === 'si' ? 'Sí' : 'No';
          const tipoDiscapacidadVal = getCellValue(ws, 5, 6);
          const alergicoVal = getCellValue(ws, 5, 7) === 'Sí' || getCellValue(ws, 5, 7).toLowerCase() === 'si' ? 'Sí' : 'No';
          const medAlergicoVal = getCellValue(ws, 5, 8);

          // Row 9 (Index 8) values
          const fechaIngVal = getCellValue(ws, 8, 0) || new Date().toISOString().split('T')[0];
          const dirProcedenciaVal = getCellValue(ws, 8, 2);
          const estadoVal = getCellValue(ws, 8, 3);
          const municipioVal = getCellValue(ws, 8, 4);
          const parroquiaVal = getCellValue(ws, 8, 5);
          const respFamVal = getCellValue(ws, 8, 6);
          const telRespVal = formatVenezuelaPhone(getCellValue(ws, 8, 7));

          // Row 26 (Index 25) value
          const situacionActualVal = getCellValue(ws, 25, 0);

          // Parse family group from row 12 up to row 21 (index 11 to 20)
          const matchingFam: Familiar[] = [];
          for (let rowIdx = 11; rowIdx <= 22; rowIdx++) {
            const famNombre = getCellValue(ws, rowIdx, 2);
            if (!famNombre) continue; // Skip blank family rows

            let famSex: 'Masculino' | 'Femenino' | 'Otro' = 'Masculino';
            const rFSex = getCellValue(ws, rowIdx, 3).toLowerCase();
            if (rFSex.includes('fem') || rFSex.startsWith('f')) famSex = 'Femenino';
            else if (rFSex.includes('otr') || rFSex.startsWith('o')) famSex = 'Otro';

            matchingFam.push({
              id: `fam-${Date.now()}-${rowIdx}`,
              parentezco: getCellValue(ws, rowIdx, 0) || 'Otro',
              edad: Number(getCellValue(ws, rowIdx, 1)) || 0,
              nombresApellidos: famNombre,
              sexo: famSex,
              tallaCamisa: getCellValue(ws, rowIdx, 4) || 'M',
              tallaPantalon: getCellValue(ws, rowIdx, 5) || '30',
              numeroCalzado: getCellValue(ws, rowIdx, 6) || '38',
              tipoEnfermedad: getCellValue(ws, rowIdx, 7) || 'Ninguna',
              alergica: getCellValue(ws, rowIdx, 8) === 'Sí' || getCellValue(ws, rowIdx, 8).toLowerCase() === 'si' ? 'Sí' : 'No'
            });
          }

          const singleFicha: FichaSocial = {
            id,
            cedula: cedulaVal,
            nombres: nombresVal,
            apellidos: apellidosVal,
            fechaNacimiento: birthVal || new Date().toISOString().split('T')[0],
            edad: ageVal,
            telefono: telVal,
            sexo: sexVal,
            gradoInstruccion: gradoInst || 'No Definido',
            tallaCamisa: tallaCamisaVal || 'M',
            tallaPantalon: tallaPantalonVal || '32',
            numeroCalzado: numCalzadoVal || '40',
            profesionOficio: profOficioVal || 'Ninguno',
            tipoEnfermedad: tipoEnfermedadVal || 'Ninguna',
            tratamientoMedicoActivo: tratActivoVal,
            discapacidad: discapacidadVal,
            tipoDiscapacidad: tipoDiscapacidadVal || 'Ninguna',
            alergico: alergicoVal,
            medicamentoAlergico: medAlergicoVal,
            fechaIngreso: fechaIngVal,
            cantidadPersonas: 1 + matchingFam.length,
            direccionProcedencia: dirProcedenciaVal || 'No Definida',
            estado: estadoVal || 'Otro',
            municipio: municipioVal || 'Otro',
            parroquia: parroquiaVal || 'Otro',
            responsableFamilia: respFamVal || 'No Definido',
            telefonoResponsable: telRespVal,
            grupoFamiliar: matchingFam,
            situacionActual: situacionActualVal || 'Sin observaciones.',
            imagenes: [],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          fichas.push(singleFicha);

        } else {
          // MODE B: TRADITIONAL MULTI-ROW TABULAR LAYOUT
          const sheetJefeName = workbook.SheetNames.find(name => name.toLowerCase().includes('jefe')) || workbook.SheetNames[0];
          const sheetFamiliarName = workbook.SheetNames.find(name => name.toLowerCase().includes('familiar')) || workbook.SheetNames[1];

          const rawJefes: any[] = XLSX.utils.sheet_to_json(workbook.Sheets[sheetJefeName]);
          const rawFamiliares: any[] = sheetFamiliarName 
            ? XLSX.utils.sheet_to_json(workbook.Sheets[sheetFamiliarName])
            : [];

          rawJefes.forEach((row, index) => {
            const cedulaVal = String(row['Cedula Jefe'] || row['Cédula'] || row['CEDULA'] || '').trim();
            if (!cedulaVal) return; // Skip empty Cédula

            const nombresVal = String(row['Nombres Jefe'] || row['Nombres'] || '').trim();
            const apellidosVal = String(row['Apellidos Jefe'] || row['Apellidos'] || '').trim();
            
            let birthVal = row['Fecha Nacimiento (AAAA-MM-DD)'] || row['Fecha Nacimiento'] || row['FECHA DE NACIEMNTO'] || '';
            if (birthVal instanceof Date) {
              birthVal = birthVal.toISOString().split('T')[0];
            } else if (typeof birthVal === 'string') {
              birthVal = birthVal.trim();
            }

            let ingresoVal = row['Fecha Ingreso (AAAA-MM-DD)'] || row['Fecha Ingreso'] || row['FECHA INGRESO'] || '';
            if (ingresoVal instanceof Date) {
              ingresoVal = ingresoVal.toISOString().split('T')[0];
            } else if (typeof ingresoVal === 'string') {
              ingresoVal = ingresoVal.trim();
            }

            const ageCalculated = calculateAge(birthVal, ingresoVal);
            const telVal = formatVenezuelaPhone(String(row['Telefono'] || row['TELEFONO'] || ''));
            const telRespVal = formatVenezuelaPhone(String(row['Telefono Responsable'] || ''));

            let sexVal: 'Masculino' | 'Femenino' | 'Otro' = 'Masculino';
            const rawSex = String(row['Sexo (Masculino/Femenino/Otro)'] || row['Sexo'] || '').toLowerCase();
            if (rawSex.includes('fem') || rawSex.startsWith('f')) sexVal = 'Femenino';
            else if (rawSex.includes('otr') || rawSex.startsWith('o')) sexVal = 'Otro';

            const id = `ficha-${Date.now()}-${index}`;

            const matchingFam: Familiar[] = rawFamiliares
              .filter(famRow => {
                const fCedJefe = String(famRow['Cedula Jefe'] || famRow['Cedula'] || '').trim();
                return fCedJefe === cedulaVal;
              })
              .map((famRow, fIndex) => {
                let fSex: 'Masculino' | 'Femenino' | 'Otro' = 'Masculino';
                const rawFSex = String(famRow['Sexo Familiar (Masculino/Femenino/Otro)'] || famRow['Sexo'] || '').toLowerCase();
                if (rawFSex.includes('fem') || rawFSex.startsWith('f')) fSex = 'Femenino';
                else if (rawFSex.includes('otr') || rawFSex.startsWith('o')) fSex = 'Otro';

                return {
                  id: `fam-${Date.now()}-${fIndex}-${index}`,
                  parentezco: String(famRow['Parentezco'] || 'Otro').trim(),
                  nombresApellidos: String(famRow['Nombres y Apellidos Familiar'] || '').trim(),
                  edad: Number(famRow['Edad Familiar'] || 0),
                  sexo: fSex,
                  tallaCamisa: String(famRow['Talla Camisa'] || 'M').trim(),
                  tallaPantalon: String(famRow['Talla Pantalon'] || '30').trim(),
                  numeroCalzado: String(famRow['Numero Calzado'] || '38').trim(),
                  tipoEnfermedad: String(famRow['Tipo Enfermedad'] || 'Ninguna').trim(),
                  alergica: String(famRow['Alergico (Si/No)'] || '').toLowerCase() === 'sí' || String(famRow['Alergico (Si/No)'] || '').toLowerCase() === 'si' ? 'Sí' : 'No'
                };
              });

            const ficha: FichaSocial = {
              id,
              cedula: cedulaVal,
              nombres: nombresVal,
              apellidos: apellidosVal,
              fechaNacimiento: birthVal || new Date().toISOString().split('T')[0],
              edad: ageCalculated,
              telefono: telVal,
              sexo: sexVal,
              gradoInstruccion: String(row['Grado Instruccion'] || 'No Definido').trim(),
              tallaCamisa: String(row['Talla Camisa'] || 'M').trim(),
              tallaPantalon: String(row['Talla Pantalon'] || '32').trim(),
              numeroCalzado: String(row['Numero Calzado'] || '40').trim(),
              profesionOficio: String(row['Profesion/Oficio'] || 'Ninguno').trim(),
              tipoEnfermedad: String(row['Tipo Enfermedad'] || 'Ninguna').trim(),
              tratamientoMedicoActivo: String(row['Tratamiento Medico Activo (Si/No)'] || '').toLowerCase() === 'sí' || String(row['Tratamiento Medico Activo (Si/No)'] || '').toLowerCase() === 'si' ? 'Sí' : 'No',
              discapacidad: String(row['Discapacidad (Si/No)'] || '').toLowerCase() === 'sí' || String(row['Discapacidad (Si/No)'] || '').toLowerCase() === 'si' ? 'Sí' : 'No',
              tipoDiscapacidad: String(row['Tipo Discapacidad'] || 'Ninguna').trim(),
              alergico: String(row['Alergico (Si/No)'] || '').toLowerCase() === 'sí' || String(row['Alergico (Si/No)'] || '').toLowerCase() === 'si' ? 'Sí' : 'No',
              medicamentoAlergico: String(row['Medicamento Alergico'] || '').trim(),
              fechaIngreso: ingresoVal || new Date().toISOString().split('T')[0],
              cantidadPersonas: 1 + matchingFam.length,
              direccionProcedencia: String(row['Direccion Procedencia'] || 'No Definida').trim(),
              estado: String(row['Estado'] || 'Otro').trim(),
              municipio: String(row['Municipio'] || 'Otro').trim(),
              parroquia: String(row['Parroquia'] || 'Otro').trim(),
              responsableFamilia: String(row['Responsable Familia'] || 'No Definido').trim(),
              telefonoResponsable: telRespVal,
              grupoFamiliar: matchingFam,
              situacionActual: String(row['Situacion Actual'] || 'Sin observaciones.').trim(),
              imagenes: [],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };

            fichas.push(ficha);
          });
        }

        resolve(fichas);
      } catch (err) {
        reject(new Error(`Error al procesar el archivo Excel: ${(err as Error).message}`));
      }
    };

    reader.onerror = () => {
      reject(new Error('No se pudo leer el archivo.'));
    };

    reader.readAsBinaryString(file);
  });
}
