/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { FichaSocial } from '../types';

/**
 * Generates and downloads a beautiful, highly detailed PDF of a single "Ficha de Caracterización Social"
 * mirroring the sections of the official sheet.
 */
export function exportFichaPDF(ficha: FichaSocial) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 12;
  let y = margin;

  // Colors
  const primaryColor = [13, 110, 139]; // Teal / Azul oscuro
  const secondaryColor = [80, 80, 80]; // Gris oscuro
  const lightBgColor = [245, 247, 248]; // Off-white
  const accentColor = [220, 53, 69]; // Rojo para alertas

  // Helper functions
  const drawHeader = (title: string) => {
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(margin, y, pageWidth - (margin * 2), 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(255, 255, 255);
    doc.text(title, pageWidth / 2, y + 5.5, { align: 'center' });
    doc.setTextColor(0, 0, 0);
    y += 11;
  };

  const drawRowBackground = (height: number) => {
    doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
    doc.rect(margin, y - 1, pageWidth - (margin * 2), height, 'F');
  };

  const drawBorder = () => {
    doc.setDrawColor(200, 200, 200);
    doc.rect(margin, margin, pageWidth - (margin * 2), pageHeight - (margin * 2));
  };

  // 1. PAGE TITLE & DECORATION
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('FICHA CARACTERIZACIÓN SOCIAL DE DAMNIFICADOS', pageWidth / 2, y + 4, { align: 'center' });
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text(`ID Ficha: ${ficha.id}  |  Fecha Registro: ${new Date(ficha.createdAt).toLocaleDateString()}`, pageWidth / 2, y + 8, { align: 'center' });
  
  y += 13;

  // 2. DATOS JEFE O JEFA DE FAMILIA
  drawHeader('DATOS JEFE O JEFA DE FAMILIA');
  
  // Grid row 1
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('CÉDULA:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.cedula, margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('NOMBRES:', margin + 40, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.nombres, margin + 40, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('APELLIDOS:', margin + 105, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.apellidos, margin + 105, y + 8);

  y += 15;

  // Grid row 2
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('F. NACIMIENTO:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.fechaNacimiento, margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('EDAD (Cargada):', margin + 40, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${ficha.edad} años`, margin + 40, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TELÉFONO:', margin + 75, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.telefono, margin + 75, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('SEXO:', margin + 115, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.sexo, margin + 115, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('G. INSTRUCCIÓN:', margin + 140, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(ficha.gradoInstruccion, margin + 140, y + 8);

  y += 15;

  // Grid row 3
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TALLA CAMISA:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.tallaCamisa, margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TALLA PANTALÓN:', margin + 35, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.tallaPantalon, margin + 35, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('N° CALZADO:', margin + 70, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.numeroCalzado, margin + 70, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('PROFESIÓN / OFICIO:', margin + 105, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.profesionOficio, margin + 105, y + 8);

  y += 15;

  // Grid row 4 (Salud)
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TIPO ENFERMEDAD:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.tipoEnfermedad || 'Ninguna', margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TRATAMIENTO ACTIVO:', margin + 50, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.tratamientoMedicoActivo, margin + 50, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('DISCAPACIDAD:', margin + 95, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${ficha.discapacidad} ${ficha.discapacidad === 'Sí' ? `(${ficha.tipoDiscapacidad})` : ''}`, margin + 95, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ALÉRGICO:', margin + 145, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${ficha.alergico} ${ficha.alergico === 'Sí' ? `(${ficha.medicamentoAlergico})` : ''}`, margin + 145, y + 8);

  y += 17;

  // 3. EQUIPO RESPONSABLE DE FAMILIA
  drawHeader('EQUIPO RESPONSABLE DE FAMILIA');
  
  // Grid row 1
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('FECHA INGRESO:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.fechaIngreso, margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('CANTIDAD DE PERSONAS:', margin + 45, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(`${ficha.cantidadPersonas} (Jefe + ${ficha.grupoFamiliar.length} familiares)`, margin + 45, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('DIR. PROCEDENCIA:', margin + 95, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  const dirLines = doc.splitTextToSize(ficha.direccionProcedencia || 'No indicada', pageWidth - margin - (margin + 95));
  doc.text(dirLines, margin + 95, y + 7);

  y += 15;

  // Grid row 2 (Territorio)
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('ESTADO:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.estado, margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('MUNICIPIO:', margin + 45, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.municipio, margin + 45, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('PARROQUIA:', margin + 105, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.parroquia, margin + 105, y + 8);

  y += 15;

  // Grid row 3 (Responsable)
  drawRowBackground(14);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('RESPONSABLE DEL EQUIPO:', margin + 3, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.responsableFamilia || 'No Definido', margin + 3, y + 8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('TELÉFONO RESPONSABLE:', margin + 95, y + 3);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(ficha.telefonoResponsable || 'No indicado', margin + 95, y + 8);

  y += 17;

  // 4. DATOS GRUPO FAMILIAR (TABLE)
  drawHeader('DATOS GRUPO FAMILIAR');
  
  if (ficha.grupoFamiliar.length === 0) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text('No se registraron integrantes del grupo familiar.', margin + 3, y + 2);
    y += 10;
  } else {
    // Draw table header
    doc.setFillColor(235, 238, 240);
    doc.rect(margin, y, pageWidth - (margin * 2), 6, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.text('PARENTEZCO', margin + 2, y + 4.5);
    doc.text('NOMBRES Y APELLIDOS', margin + 30, y + 4.5);
    doc.text('EDAD', margin + 85, y + 4.5);
    doc.text('SEXO', margin + 98, y + 4.5);
    doc.text('T. CAMISA', margin + 115, y + 4.5);
    doc.text('T. PANTALÓN', margin + 133, y + 4.5);
    doc.text('CALZADO', margin + 155, y + 4.5);
    doc.text('ENFERMEDAD', margin + 172, y + 4.5);
    
    y += 6;

    // Table rows
    ficha.grupoFamiliar.forEach((fam, index) => {
      if (y > pageHeight - margin - 20) {
        doc.addPage();
        y = margin;
        drawBorder();
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.text('DATOS GRUPO FAMILIAR (CONTINUACIÓN)', margin + 3, y + 4);
        y += 8;
        // Re-draw table header
        doc.setFillColor(235, 238, 240);
        doc.rect(margin, y, pageWidth - (margin * 2), 6, 'F');
        doc.text('PARENTEZCO', margin + 2, y + 4.5);
        doc.text('NOMBRES Y APELLIDOS', margin + 30, y + 4.5);
        doc.text('EDAD', margin + 85, y + 4.5);
        doc.text('SEXO', margin + 98, y + 4.5);
        doc.text('T. CAMISA', margin + 115, y + 4.5);
        doc.text('T. PANTALÓN', margin + 133, y + 4.5);
        doc.text('CALZADO', margin + 155, y + 4.5);
        doc.text('ENFERMEDAD', margin + 172, y + 4.5);
        y += 6;
      }

      // Alternating row background
      if (index % 2 === 1) {
        doc.setFillColor(248, 249, 250);
        doc.rect(margin, y, pageWidth - (margin * 2), 6, 'F');
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.text(fam.parentezco, margin + 2, y + 4.5);
      
      const truncName = fam.nombresApellidos.length > 28 ? fam.nombresApellidos.substring(0, 26) + '..' : fam.nombresApellidos;
      doc.text(truncName, margin + 30, y + 4.5);
      
      doc.text(`${fam.edad} a.`, margin + 85, y + 4.5);
      doc.text(fam.sexo.substring(0, 3), margin + 98, y + 4.5);
      doc.text(fam.tallaCamisa, margin + 115, y + 4.5);
      doc.text(fam.tallaPantalon, margin + 133, y + 4.5);
      doc.text(fam.numeroCalzado, margin + 155, y + 4.5);
      
      const truncEnf = fam.tipoEnfermedad.length > 15 ? fam.tipoEnfermedad.substring(0, 13) + '..' : fam.tipoEnfermedad;
      doc.text(truncEnf, margin + 172, y + 4.5);

      y += 6;
    });
    y += 4;
  }

  // 5. SITUACIÓN ACTUAL & DETALLES
  if (y > pageHeight - margin - 35) {
    doc.addPage();
    y = margin;
    drawBorder();
  }
  
  drawHeader('SITUACIÓN ACTUAL / OBSERVACIONES GENERALES');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  
  const textLines = doc.splitTextToSize(ficha.situacionActual || 'Sin observaciones detalladas cargadas.', pageWidth - (margin * 2) - 6);
  doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
  const boxHeight = Math.max(16, textLines.length * 4.5 + 4);
  doc.rect(margin, y, pageWidth - (margin * 2), boxHeight, 'F');
  
  doc.text(textLines, margin + 3, y + 6);
  y += boxHeight + 8;

  // 6. MEMORIA FOTOGRÁFICA
  if (ficha.imagenes && ficha.imagenes.length > 0) {
    if (y > pageHeight - margin - 50) {
      doc.addPage();
      y = margin;
      drawBorder();
    }
    
    drawHeader('MEMORIA FOTOGRÁFICA');
    
    let imgX = margin + 4;
    let imgWidth = 52;
    let imgHeight = 39;
    
    ficha.imagenes.forEach((base64, index) => {
      // Check if image overflows right margin, if so jump to next row
      if (imgX + imgWidth > pageWidth - margin) {
        imgX = margin + 4;
        y += imgHeight + 6;
      }
      
      // If row overflows bottom margin, add new page
      if (y + imgHeight > pageHeight - margin - 10) {
        doc.addPage();
        y = margin;
        drawBorder();
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8);
        doc.text('MEMORIA FOTOGRÁFICA (CONTINUACIÓN)', margin + 3, y + 4);
        y += 8;
        imgX = margin + 4;
      }

      try {
        doc.addImage(base64, 'JPEG', imgX, y, imgWidth, imgHeight);
        doc.setDrawColor(180, 180, 180);
        doc.rect(imgX, y, imgWidth, imgHeight, 'S');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7);
        doc.text(`Fotografía ${index + 1}`, imgX + 2, y + imgHeight + 4);
      } catch (err) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8);
        doc.text('[Error de Imagen]', imgX + 5, y + 10);
      }
      
      imgX += imgWidth + 6;
    });
  }

  // Draw final border around all pages
  const totalPages = (doc.internal as any).pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    drawBorder();
    
    // Page footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text(`Sistema de Gestión de Caracterización Social - Venezuela`, margin + 3, pageHeight - margin + 4);
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin - 18, pageHeight - margin + 4);
  }

  doc.save(`Ficha_Social_${ficha.cedula}.pdf`);
}

/**
 * Generates and downloads a beautifully compiled Executive Management Report as PDF.
 */
export function exportReporteResumenPDF(fichas: FichaSocial[], stats: any) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  let y = margin;

  const primaryColor = [13, 110, 139]; // Teal / Azul oscuro
  const secondaryColor = [80, 80, 80]; // Gris oscuro
  const lightBgColor = [245, 247, 248];

  const drawBorder = () => {
    doc.setDrawColor(180, 180, 180);
    doc.rect(margin, margin, pageWidth - (margin * 2), pageHeight - (margin * 2));
  };

  drawBorder();

  // Header Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('REPORTE EJECUTIVO Y RESUMEN DE GESTIÓN', pageWidth / 2, y + 6, { align: 'center' });
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
  doc.text('CARACTERIZACIÓN SOCIAL DE FAMILIAS DAMNIFICADAS', pageWidth / 2, y + 12, { align: 'center' });
  doc.setFontSize(8.5);
  doc.text(`Fecha Reporte: ${new Date().toLocaleString()} | Total Fichas: ${fichas.length}`, pageWidth / 2, y + 17, { align: 'center' });
  
  y += 24;

  // 1. INDICADORES GENERALES DE GESTIÓN (BENTO METRICS BOXES)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('1. Indicadores de Gestión Generales', margin + 3, y);
  y += 4;

  const boxW = 54;
  const boxH = 18;
  const metrics = [
    { label: 'Familias Damnificadas', val: `${fichas.length}` },
    { label: 'Personas Protegidas', val: `${stats.totalPersonas || 0}` },
    { label: 'Edad Promedio Jefes', val: `${stats.edadPromedio || 0} años` }
  ];

  metrics.forEach((m, idx) => {
    const x = margin + idx * (boxW + 5);
    doc.setFillColor(240, 244, 246);
    doc.rect(x, y, boxW, boxH, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.text(m.val, x + boxW / 2, y + 7, { align: 'center' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text(m.label, x + boxW / 2, y + 13, { align: 'center' });
  });

  y += boxH + 10;

  // 2. DISTRIBUCIÓN TERRITORIAL
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('2. Distribución Territorial (Top de Zonas Afectadas)', margin + 3, y);
  y += 5;

  doc.setFillColor(245, 245, 245);
  doc.rect(margin, y, pageWidth - (margin * 2), 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(0, 0, 0);
  doc.text('ESTADO', margin + 4, y + 4);
  doc.text('MUNICIPIO / PARROQUIA', margin + 45, y + 4);
  doc.text('FICHAS REGISTRADAS', margin + 115, y + 4);
  doc.text('PARTICIPACIÓN (%)', margin + 150, y + 4);
  y += 6;

  const topEstados = Object.entries(stats.distribucionEstados || {})
    .sort((a: any, b: any) => b[1] - a[1])
    .slice(0, 6);

  if (topEstados.length === 0) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.text('No hay datos territoriales disponibles.', margin + 4, y + 5);
    y += 10;
  } else {
    topEstados.forEach(([estado, count]: any, index) => {
      // Find sample parish
      const firstFicha = fichas.find(f => f.estado === estado);
      const locDetail = firstFicha ? `${firstFicha.municipio} / ${firstFicha.parroquia}` : 'Varios';
      const pct = ((count / fichas.length) * 100).toFixed(1);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(estado, margin + 4, y + 4);
      doc.text(locDetail, margin + 45, y + 4);
      doc.text(`${count} familias`, margin + 115, y + 4);
      doc.text(`${pct}%`, margin + 150, y + 4);
      
      doc.setDrawColor(230, 230, 230);
      doc.line(margin, y + 6, pageWidth - margin, y + 6);
      y += 6.5;
    });
  }

  y += 5;

  // 3. CONDICIONES DE SALUD Y VULNERABILIDAD
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
  doc.text('3. Cuadro de Vulnerabilidad y Salud Colectiva', margin + 3, y);
  y += 5;

  const vulnMetrics = [
    { item: 'Jefes con Enfermedades Crónicas', count: stats.conEnfermedad || 0 },
    { item: 'Jefes con Discapacidad Registrada', count: stats.conDiscapacidad || 0 },
    { item: 'Jefes con Alergias Crónicas', count: stats.conAlergias || 0 },
    { item: 'Miembros de Familia Registrados', count: (stats.totalPersonas || 0) - fichas.length }
  ];

  doc.setFillColor(245, 245, 245);
  doc.rect(margin, y, pageWidth - (margin * 2), 6, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text('INDICADOR DE VULNERABILIDAD', margin + 4, y + 4);
  doc.text('CASOS DETECTADOS', margin + 115, y + 4);
  doc.text('% RESPECTO AL TOTAL', margin + 150, y + 4);
  y += 6;

  vulnMetrics.forEach((v) => {
    const pct = fichas.length > 0 ? ((v.count / fichas.length) * 100).toFixed(1) : '0.0';
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.text(v.item, margin + 4, y + 4);
    doc.text(`${v.count} personas`, margin + 115, y + 4);
    doc.text(v.item.includes('Miembros') ? 'N/A' : `${pct}%`, margin + 150, y + 4);

    doc.setDrawColor(230, 230, 230);
    doc.line(margin, y + 6, pageWidth - margin, y + 6);
    y += 6.5;
  });

  y += 10;

  // 4. FIRMAS RESPONSABLES
  if (y > pageHeight - margin - 35) {
    doc.addPage();
    y = margin;
    drawBorder();
  }

  y = pageHeight - margin - 30;
  doc.setDrawColor(180, 180, 180);
  doc.line(margin + 15, y, margin + 65, y);
  doc.line(pageWidth - margin - 65, y, pageWidth - margin - 15, y);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('EQUIPO EVALUADOR / RECOPILADOR', margin + 40, y + 4, { align: 'center' });
  doc.text('COORDINACIÓN DE GESTIÓN SOCIAL', pageWidth - margin - 40, y + 4, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.text('Firma y Sello', margin + 40, y + 8, { align: 'center' });
  doc.text('Firma Autorizada y Sello', pageWidth - margin - 40, y + 8, { align: 'center' });

  // Final settings for all pages
  const totalPages = (doc.internal as any).pages.length - 1;
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    // Page footer
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.text(`Gobierno de la República Bolivariana de Venezuela - Reportes de Gestión`, margin + 3, pageHeight - margin + 4);
    doc.text(`Página ${i} de ${totalPages}`, pageWidth - margin - 18, pageHeight - margin + 4);
  }

  doc.save('Reporte_Resumen_Gestion_Damnificados.pdf');
}
