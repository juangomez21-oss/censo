/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { Download, Upload, RotateCcw, CheckCircle2, AlertCircle, RefreshCw, FileText } from 'lucide-react';
import { FichaSocial } from '../types';

interface MantenimientoProps {
  fichas: FichaSocial[];
  onRestoreBackup: (allFichas: FichaSocial[]) => void;
}

export default function Mantenimiento({
  fichas,
  onRestoreBackup
}: MantenimientoProps) {
  const jsonFileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 6000);
  };

  // 1. Database Backup (Download JSON)
  const handleDatabaseBackup = () => {
    try {
      const dataStr = JSON.stringify(fichas, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const exportFileDefaultName = `Respaldo_Fichas_Sociales_${new Date().toISOString().split('T')[0]}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', exportFileDefaultName);
      linkElement.click();
      
      showMessage('success', 'Respaldo Completo (.json) creado e instalado con éxito en sus descargas locales.');
    } catch (e) {
      showMessage('error', 'Error al realizar el respaldo físico de la base de datos.');
    }
  };

  // 2. Database Restore (Upload JSON)
  const handleDatabaseRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const result = event.target?.result;
        if (typeof result !== 'string') throw new Error('Contenido de archivo ilegible');
        
        const restoredFichas = JSON.parse(result);
        if (!Array.isArray(restoredFichas)) throw new Error('La estructura de datos de respaldo debe ser un listado de fichas.');

        if (restoredFichas.length > 0) {
          const sample = restoredFichas[0];
          if (!('cedula' in sample) || !('nombres' in sample) || !('grupoFamiliar' in sample)) {
            throw new Error('Las propiedades del censo no corresponden con el formato de caracterización social.');
          }
        }

        onRestoreBackup(restoredFichas);
        showMessage('success', `Restauración Exitosa: Se han cargado ${restoredFichas.length} registros desde el archivo de copia de seguridad.`);
      } catch (err) {
        showMessage('error', `Fallo al procesar restauración: ${(err as Error).message}`);
      } finally {
        setLoading(false);
        if (jsonFileInputRef.current) jsonFileInputRef.current.value = '';
      }
    };
    reader.onerror = () => {
      setLoading(false);
      showMessage('error', 'Error al leer el archivo físico de respaldo.');
    };
    reader.readAsText(file);
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8" id="panel-mantenimiento">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-800 uppercase tracking-tight">Mantenimiento y Respaldo de Datos</h2>
          <p className="text-xs text-slate-500 mt-1">Crea copias de resguardo y restaura la base de datos para salvaguardar el censo social.</p>
        </div>
        <div className="mt-2 sm:mt-0 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-md text-[11px] font-bold text-indigo-600 uppercase">
          Estado Fichas: {fichas.length > 0 ? 'DATOS SEGUROS' : 'CENSO VACÍO'}
        </div>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-lg flex items-start gap-3 text-xs sm:text-sm ${
          message.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'
        }`}>
          {message.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="font-bold">{message.type === 'success' ? 'Operación Exitosa' : 'Atención'}</p>
            <p className="mt-1 leading-relaxed text-slate-600 font-medium">{message.text}</p>
          </div>
        </div>
      )}

      {/* CORE UTILITY BOXES */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* DOWNLOAD BACKUP BLOCK */}
        <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700 mb-4 shadow-3xs">
              <Download className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Crear Copia de Seguridad</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Descarga un archivo encriptado en formato estructurado JSON conteniendo el censo social completo, los jefes de familia, integrantes, situaciones individuales y la memoria fotográfica vinculada.
            </p>
          </div>
          
          <div className="mt-6">
            <button
              onClick={handleDatabaseBackup}
              disabled={fichas.length === 0}
              className={`w-full flex items-center justify-center gap-2 py-3 px-4 font-bold text-xs uppercase tracking-wide rounded-lg border transition-all shadow-3xs transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer ${
                fichas.length === 0
                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed shadow-none'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700'
              }`}
              id="btn-crear-respaldo-json"
            >
              <Download className="w-4 h-4 text-white shrink-0" />
              <span>Crear Respaldo (.json)</span>
            </button>
          </div>
        </div>

        {/* UPLOAD RESTORE BLOCK */}
        <div className="p-6 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700 mb-4 shadow-3xs">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-slate-800 text-sm uppercase tracking-wider">Restaurar Copia de Seguridad</h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Sube un archivo de respaldo JSON generado previamente en esta plataforma para restaurar la totalidad de las fichas de caracterización social. <strong>Advertencia:</strong> Reemplazará los registros actualmente en memoria.
            </p>
          </div>
          
          <div className="mt-6">
            <label className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-wide rounded-lg border border-emerald-700 transition-all shadow-3xs transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer text-center">
              <RefreshCw className={`w-4 h-4 text-white shrink-0 ${loading ? 'animate-spin' : ''}`} />
              <span>{loading ? 'Subiendo...' : 'Restaurar Respaldo (.json)'}</span>
              <input
                ref={jsonFileInputRef}
                type="file"
                accept=".json"
                onChange={handleDatabaseRestore}
                className="hidden"
                disabled={loading}
              />
            </label>
          </div>
        </div>

      </div>

    </div>
  );
}
