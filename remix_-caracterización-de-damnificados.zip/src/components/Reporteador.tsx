/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Search, FileText, Check, FileDown, RotateCcw, HelpCircle, FileSpreadsheet } from 'lucide-react';
import { FichaSocial } from '../types';
import { exportToExcel } from '../utils/excelHelper';
import { exportReporteResumenPDF } from '../utils/pdfHelper';

interface ReporteadorProps {
  fichas: FichaSocial[];
  stats: any;
}

export default function Reporteador({ fichas, stats }: ReporteadorProps) {
  // Filter states
  const [busqueda, setBusqueda] = useState('');
  const [coordinacion, setCoordinacion] = useState('Todas');
  const [ubicacion, setUbicacion] = useState('Todas');
  const [inspeccionado, setInspeccionado] = useState('Cualquiera');
  const [tipoResidencia, setTipoResidencia] = useState('Todos');
  const [gradoDano, setGradoDano] = useState('Todos');
  const [estadoDano, setEstadoDano] = useState('Todas');
  const [correlativoDesde, setCorrelativoDesde] = useState('');
  const [correlativoHasta, setCorrelativoHasta] = useState('');

  // Output format state
  const [formatoSalida, setFormatoSalida] = useState<'Excel' | 'CSV' | 'PDF Tabular'>('Excel');

  // Reset all filters
  const handleResetCriterios = () => {
    setBusqueda('');
    setCoordinacion('Todas');
    setUbicacion('Todas');
    setInspeccionado('Cualquiera');
    setTipoResidencia('Todos');
    setGradoDano('Todos');
    setEstadoDano('Todas');
    setCorrelativoDesde('');
    setCorrelativoHasta('');
  };

  // Perform dynamic filtering based on selections
  const filteredFichas = useMemo(() => {
    return fichas.filter((ficha, idx) => {
      // 1. General search (Cédula, Nombres, Apellidos, Dirección, Estado, etc.)
      if (busqueda) {
        const query = busqueda.toLowerCase();
        const matchesQuery = 
          ficha.cedula.toLowerCase().includes(query) ||
          ficha.nombres.toLowerCase().includes(query) ||
          ficha.apellidos.toLowerCase().includes(query) ||
          (ficha.direccionProcedencia && ficha.direccionProcedencia.toLowerCase().includes(query)) ||
          ficha.estado.toLowerCase().includes(query);
        if (!matchesQuery) return false;
      }

      // 2. Coordinación (Corresponds to responsableFamilia in this dataset)
      if (coordinacion !== 'Todas') {
        const isCentral = coordinacion === 'Coordinación Central' && (ficha.responsableFamilia?.toLowerCase().includes('carlos') || ficha.responsableFamilia?.toLowerCase().includes('gómez'));
        const isMetropolitana = coordinacion === 'Coordinación Metropolitana' && (ficha.responsableFamilia?.toLowerCase().includes('ana') || ficha.responsableFamilia?.toLowerCase().includes('hernández'));
        const isRefugios = coordinacion === 'Coordinación de Refugios' && !ficha.responsableFamilia;
        
        if (coordinacion === 'Coordinación Central' && !isCentral) return false;
        if (coordinacion === 'Coordinación Metropolitana' && !isMetropolitana) return false;
        if (coordinacion === 'Coordinación de Refugios' && !isRefugios) return false;
      }

      // 3. Estatus Albergue / Ubicación
      if (ubicacion !== 'Todas') {
        const textToSearch = `${ficha.direccionProcedencia} ${ficha.situacionActual}`.toLowerCase();
        if (ubicacion === 'Albergue Temporal' && !textToSearch.includes('albergue')) return false;
        if (ubicacion === 'Refugio Solidario' && !textToSearch.includes('refugio')) return false;
        if (ubicacion === 'Casa de Familiares' && !textToSearch.includes('familiar')) return false;
      }

      // 4. ¿Inspeccionado en Campo?
      if (inspeccionado !== 'Cualquiera') {
        const hasResponsable = !!ficha.responsableFamilia && ficha.responsableFamilia !== 'No Definido';
        if (inspeccionado === 'SÍ' && !hasResponsable) return false;
        if (inspeccionado === 'NO' && hasResponsable) return false;
      }

      // 5. Tipo Residencia
      if (tipoResidencia !== 'Todos') {
        const textToSearch = `${ficha.situacionActual} ${ficha.direccionProcedencia}`.toLowerCase();
        const resType = tipoResidencia.toLowerCase();
        if (resType === 'rancho' && !textToSearch.includes('rancho')) return false;
        if (resType === 'casa' && !textToSearch.includes('casa')) return false;
        if (resType === 'apartamento' && !textToSearch.includes('apartamento')) return false;
        if (resType === 'improvisado' && !textToSearch.includes('improvisado')) return false;
      }

      // 6. Grado de Daño
      if (gradoDano !== 'Todos') {
        const textToSearch = ficha.situacionActual.toLowerCase();
        const rDamage = gradoDano.toLowerCase();
        if (rDamage === 'pérdida total' && !textToSearch.includes('pérdida') && !textToSearch.includes('total')) return false;
        if (rDamage === 'grave' && !textToSearch.includes('grave') && !textToSearch.includes('severo')) return false;
        if (rDamage === 'moderado' && !textToSearch.includes('moderado') && !textToSearch.includes('medio')) return false;
        if (rDamage === 'leve' && !textToSearch.includes('leve') && !textToSearch.includes('parcial')) return false;
      }

      // 7. Estado Daño / Acción Recomendada
      if (estadoDano !== 'Todas') {
        const textToSearch = ficha.situacionActual.toLowerCase();
        const action = estadoDano.toLowerCase();
        if (action === 'reubicación inmediata' && !textToSearch.includes('reubicación') && !textToSearch.includes('reubicar')) return false;
        if (action === 'subsidio de vivienda' && !textToSearch.includes('subsidio')) return false;
        if (action === 'reparación de infraestructura' && !textToSearch.includes('reparar') && !textToSearch.includes('reparación')) return false;
        if (action === 'asistencia material' && !textToSearch.includes('asistencia') && !textToSearch.includes('enseres')) return false;
      }

      // 8. Rango Correlativo (index based, 1-indexed)
      const correlativo = idx + 1;
      if (correlativoDesde && correlativo < Number(correlativoDesde)) return false;
      if (correlativoHasta && correlativo > Number(correlativoHasta)) return false;

      return true;
    });
  }, [fichas, busqueda, coordinacion, ubicacion, inspeccionado, tipoResidencia, gradoDano, estadoDano, correlativoDesde, correlativoHasta]);

  // Handle report generation based on chosen format
  const handleGenerarReporte = () => {
    if (filteredFichas.length === 0) {
      alert('No hay registros seleccionados que coincidan con los criterios activos.');
      return;
    }

    if (formatoSalida === 'Excel') {
      exportToExcel(filteredFichas);
    } else if (formatoSalida === 'CSV') {
      const headers = [
        'CEDULA',
        'NOMBRES',
        'APELLIDOS',
        'FECHA NACIMIENTO',
        'EDAD',
        'TELEFONO',
        'SEXO',
        'ESTADO',
        'MUNICIPIO',
        'PARROQUIA',
        'SITUACION ACTUAL',
        'FECHA REGISTRO'
      ];
      
      const csvRows = [headers.join(',')];
      filteredFichas.forEach(f => {
        const row = [
          f.cedula,
          `"${f.nombres.replace(/"/g, '""')}"`,
          `"${f.apellidos.replace(/"/g, '""')}"`,
          f.fechaNacimiento,
          f.edad,
          f.telefono,
          f.sexo,
          `"${f.estado}"`,
          `"${f.municipio}"`,
          `"${f.parroquia}"`,
          `"${f.situacionActual.replace(/"/g, '""').replace(/\n/g, ' ')}"`,
          `"${new Date(f.createdAt).toLocaleDateString()}"`
        ];
        csvRows.push(row.join(','));
      });

      const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Reporte_Filtrado_${new Date().toISOString().split('T')[0]}.csv`);
      link.click();
    } else if (formatoSalida === 'PDF Tabular') {
      // Recalculate subset stats to pass to the report
      let totalPersonas = 0;
      let conEnfermedad = 0;
      let conDiscapacidad = 0;
      let conAlergias = 0;
      let totalEdadJefes = 0;
      const distribucionEstados: Record<string, number> = {};

      filteredFichas.forEach(f => {
        totalPersonas += 1 + f.grupoFamiliar.length;
        if (f.tipoEnfermedad && f.tipoEnfermedad !== 'Ninguna') conEnfermedad++;
        if (f.discapacidad === 'Sí') conDiscapacidad++;
        if (f.alergico === 'Sí') conAlergias++;
        totalEdadJefes += f.edad;
        distribucionEstados[f.estado] = (distribucionEstados[f.estado] || 0) + 1;
      });

      const localStats = {
        totalPersonas,
        conEnfermedad,
        conDiscapacidad,
        conAlergias,
        edadPromedio: filteredFichas.length > 0 ? Math.round(totalEdadJefes / filteredFichas.length) : 0,
        distribucionEstados
      };

      exportReporteResumenPDF(filteredFichas, localStats);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-6" id="seccion-reporteador">
      
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 pb-4 border-b border-slate-100">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-base sm:text-lg font-bold text-slate-800 uppercase tracking-tight">
              Módulo Reporteador de Trabajadores e Inspecciones
            </h2>
            <span className="bg-rose-50 border border-rose-100 text-rose-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
              MULTIFORMATO
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Configure los criterios para generar informes filtrados en PDF, Excel y CSV
          </p>
        </div>
        
        <button
          onClick={handleResetCriterios}
          className="mt-3 md:mt-0 flex items-center justify-center gap-2 px-3.5 py-2 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-800 text-xs font-bold uppercase border border-slate-200 rounded-lg shadow-3xs transition-all cursor-pointer"
          title="Limpiar todos los filtros"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
          <span>Restablecer Criterios</span>
        </button>
      </div>

      {/* FILTER GRID (2 rows, 4 columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-5 gap-y-4 mb-6">
        
        {/* COLUMN 1 */}
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              BÚSQUEDA GENERAL (TEXTO)
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                placeholder="Cédula, nombre, dirección..."
                className="w-full pl-9 pr-3.5 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-100 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              TIPO RESIDENCIA
            </label>
            <select
              value={tipoResidencia}
              onChange={(e) => setTipoResidencia(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Todos">Todos los Tipos</option>
              <option value="Rancho">Rancho</option>
              <option value="Casa">Casa</option>
              <option value="Apartamento">Apartamento</option>
              <option value="Improvisado">Improvisado / Invasión</option>
            </select>
          </div>
        </div>

        {/* COLUMN 2 */}
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              COORDINACIÓN
            </label>
            <select
              value={coordinacion}
              onChange={(e) => setCoordinacion(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Todas">Todas las Coordinaciones</option>
              <option value="Coordinación Central">Coordinación Central</option>
              <option value="Coordinación Metropolitana">Coordinación Metropolitana</option>
              <option value="Coordinación de Refugios">Sin Coordinación (Sin Asignar)</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              GRADO DE DAÑO
            </label>
            <select
              value={gradoDano}
              onChange={(e) => setGradoDano(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Todos">Todos los Daños</option>
              <option value="Pérdida Total">Pérdida Total</option>
              <option value="Grave">Grave</option>
              <option value="Moderado">Moderado</option>
              <option value="Leve">Leve</option>
            </select>
          </div>
        </div>

        {/* COLUMN 3 */}
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              ESTATUS ALBERGUE / UBICACIÓN
            </label>
            <select
              value={ubicacion}
              onChange={(e) => setUbicacion(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Todas">Todas las Ubicaciones</option>
              <option value="Albergue Temporal">Albergue Temporal</option>
              <option value="Refugio Solidario">Refugio Solidario</option>
              <option value="Casa de Familiares">Casa de Familiares</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              ESTADO DAÑO / ACCIÓN RECOMM.
            </label>
            <select
              value={estadoDano}
              onChange={(e) => setEstadoDano(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Todas">Todas las Acciones</option>
              <option value="Reubicación Inmediata">Reubicación Inmediata</option>
              <option value="Subsidio de Vivienda">Subsidio de Vivienda</option>
              <option value="Reparación de Infraestructura">Reparación de Infraestructura</option>
              <option value="Asistencia Material">Asistencia Material</option>
            </select>
          </div>
        </div>

        {/* COLUMN 4 */}
        <div className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              ¿INSPECCIONADO EN CAMPO?
            </label>
            <select
              value={inspeccionado}
              onChange={(e) => setInspeccionado(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 bg-white transition-colors"
            >
              <option value="Cualquiera">Cualquiera (SÍ / NO)</option>
              <option value="SÍ">SÍ (Evaluado)</option>
              <option value="NO">NO (Sin Evaluador)</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              RANGO CORRELATIVO (NRO)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={correlativoDesde}
                onChange={(e) => setCorrelativoDesde(e.target.value)}
                placeholder="Desde"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 transition-colors"
              />
              <span className="text-slate-400 font-bold">-</span>
              <input
                type="number"
                value={correlativoHasta}
                onChange={(e) => setCorrelativoHasta(e.target.value)}
                placeholder="Hasta"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>
          </div>
        </div>

      </div>

      {/* FOOTER BAR (SUMMARY BAR MATCHING THE THIRD IMAGE EXACTLY) */}
      <div className="mt-8 bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 flex flex-col lg:flex-row items-center justify-between gap-4">
        
        {/* LEFT COUNTER STATS */}
        <div className="text-xs sm:text-sm font-medium text-slate-500">
          Registros seleccionados: <strong className="text-slate-800 text-sm sm:text-base">{filteredFichas.length}</strong> de <span className="text-slate-700 font-bold">{fichas.length}</span> totales
        </div>

        {/* MIDDLE FORMAT SELECTOR */}
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">FORMATO DE SALIDA:</span>
          
          <div className="bg-slate-200 p-0.5 rounded-lg flex gap-0.5 border border-slate-200/60 shadow-3xs">
            {(['Excel', 'CSV', 'PDF Tabular'] as const).map((fmt) => (
              <button
                key={fmt}
                onClick={() => setFormatoSalida(fmt)}
                className={`px-3 py-1 text-xs font-bold rounded-md transition-all uppercase cursor-pointer ${
                  formatoSalida === fmt 
                    ? 'bg-blue-600 text-white shadow-xs' 
                    : 'text-slate-600 hover:text-slate-800 hover:bg-slate-300/40'
                }`}
              >
                {fmt === 'PDF Tabular' ? 'PDF Tabular' : fmt}
              </button>
            ))}
          </div>
        </div>

        {/* RIGHT ACTION DOWNLOAD BUTTON */}
        <button
          onClick={handleGenerarReporte}
          disabled={filteredFichas.length === 0}
          className={`flex items-center gap-2 py-3 px-6 rounded-lg text-xs font-bold uppercase tracking-wide transition-all shadow-sm cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0 ${
            filteredFichas.length === 0
              ? 'bg-slate-300 text-slate-500 border border-slate-300 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 text-white border border-blue-700 shadow-blue-100'
          }`}
          id="btn-descargar-reporte-filtrado"
        >
          <FileDown className="w-4 h-4 text-white" />
          <span>Generar y Descargar Reporte</span>
        </button>

      </div>

    </div>
  );
}
